function [robustP1Real,robustM1Real,cost_plus1,cost_minus1,possibility_self] = robust_cost_python(img_name,  maxD, seed,qf)

jpeg_old = jpeg_read(img_name);
jpeg_coef = jpeg_old.coef_arrays{1};
jpeg_size = size(jpeg_coef);
cost_plus1 = zeros(jpeg_size);
cost_minus1 = zeros(jpeg_size);
fun = @(x)x.data .*jpeg_old.quant_tables{1};
I_spatial = blockproc(jpeg_old.coef_arrays{1},[8 8],fun);
fun=@(x)idct2(x.data);
I_spatial = blockproc(I_spatial,[8 8],fun)+128; %????
C_QUANT = jpeg_old.quant_tables{1};
spatialImpact = cell(8, 8);
%minV = 0+a;
%maxV = 255-a;
cost_block = zeros(8,8);
for bcoord_i=1:8
    for bcoord_j=1:8
        testCoeffs = zeros(8, 8);
        testCoeffs(bcoord_i, bcoord_j) = 1;
        spatialImpact{bcoord_i, bcoord_j} = idct2(testCoeffs)*C_QUANT(bcoord_i, bcoord_j);
    end
end
spatial = zeros([512,512,2,64]);
index = 1;
for i=1:8
    for j=1:8
           %cost for phase ij
          spatialImp = spatialImpact{i, j};
          for ii=1:8:jpeg_size(1)
              for jj=1:8:jpeg_size(2)
                  spatial(ii:ii+7,jj:jj+7,1,index) = spatialImp + I_spatial(ii:ii+7,jj:jj+7);
              end
          end
          for ii=1:8:jpeg_size(1)
              for jj=1:8:jpeg_size(2)
                  spatial(ii:ii+7,jj:jj+7,2,index) = I_spatial(ii:ii+7,jj:jj+7) - spatialImp;
              end
          end
          for ii=1:8:jpeg_size(1)
              for jj=1:8:jpeg_size(2)
                  spatial(ii:ii+7,jj:jj+7,3,index) = I_spatial(ii:ii+7,jj:jj+7);
              end
          end
          index = index + 1;
    end
end
save([seed,'temp_spatial.mat'],'spatial','-v6');
delete([seed,'output.mat']);
call_python([seed,'temp_spatial.mat'],[seed,'output.mat'],qf);%W*H*D*P
load1 = load([seed,'output.mat']);%W*H*D*P(1-64)
all_predict = load1.predict;
   
for i=1:512
    for j=1:512
        phasea = rem(i-1,8)+1;
        phaseb = rem(j-1,8)+1;
        phase_num = (phasea-1)*8+1+(phaseb)-1;
        cost_plus1(i,j) = all_predict(i,j,1,phase_num);
        cost_minus1(i,j) = all_predict(i,j,2,phase_num);
        possibility_self(i,j) = all_predict(i,j,3,phase_num);
    end
end
%maxP = max(max(cost_plus1(:)),max(cost_minus1(:)));
%minP = min(min(cost_plus1(:)),min(cost_minus1(:)));
%robustP12 = (cost_plus1-minP)./(maxP - minP+10^-6);
%robustM12 = (cost_minus1-minP)./(maxP - minP+10^-6);
cost_plus1_copy = cost_plus1;
cost_minus1_copy  = cost_minus1;
cost_plus1_copy(cost_plus1_copy<0.5) = 0.5;
cost_minus1_copy(cost_minus1_copy<0.5) = 0.5;
maxP = max(max(cost_plus1_copy(:)),max(cost_minus1_copy(:)));
minP = min(min(cost_plus1_copy(:)),min(cost_minus1_copy(:)));
minP = 0.5;
robustP1Real = (cost_plus1_copy-minP)./(maxP - minP+10^-6);
robustM1Real = (cost_minus1_copy-minP)./(maxP - minP+10^-6);

end
        