__author__ = 'Joel Akeret'
__version__ = '0.1.2'
__credits__ = 'ETH Zurich, Institute for Astronomy'
