# tf_unet is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# tf_unet is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with tf_unet.  If not, see <http://www.gnu.org/licenses/>.


'''
Created on Jul 28, 2016

author: jakeret
'''
from __future__ import print_function, division, absolute_import, unicode_literals

import os
import shutil
import numpy as np
from collections import OrderedDict
import logging
import scipy.io as scio
import tensorflow as tf

from tf_unet import util
from tf_unet.layers import (weight_variable, weight_variable_devonc, bias_variable,
                            conv2d, deconv2d, max_pool, crop_and_concat, pixel_wise_softmax,
                            cross_entropy, concatMy, conv2dS)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')



def create_classify_net9(x, keep_prob=1, channels=1, n_class=2, layers=3, features_root=16, filter_size=3, pool_size=2,
                        summaries=True):
    """
    Creates a new convolutional unet for the given parametrization.

    :param x: input tensor, shape [?,nx,ny,channels]
    :param keep_prob: dropout probability tensor
    :param channels: number of channels in the input image
    :param n_class: number of output labels
    :param layers: number of layers in the net
    :param features_root: number of features in the first layer
    :param filter_size: size of the convolution filter
    :param pool_size: size of the max pooling operation
    :param summaries: Flag if summaries should be created
    """

    logging.info(
        "Layers {layers}, features {features}, filter size {filter_size}x{filter_size}, pool size: {pool_size}x{pool_size}".format(
            layers=layers,
            features=features_root,
            filter_size=filter_size,
            pool_size=pool_size))

    # Placeholder for the input image
    with tf.name_scope("preprocessing"):

        x_image = tf.reshape(x, tf.stack([-1, 8, 8, 1]))
        in_node = x_image

    weights = []
    biases = []
    convs = []
    pools = OrderedDict()
    deconv = OrderedDict()
    dw_h_convs = OrderedDict()
    up_h_convs = OrderedDict()

    in_size = 8
    size = in_size
    # down layers
    with tf.name_scope("conv_1"):
        features  = 16
        stddev = np.sqrt(2 / (filter_size ** 2 * features))
        w1 = weight_variable([filter_size, filter_size, channels, features], stddev, name="w1")
        w3 = weight_variable([filter_size, filter_size, channels, features], stddev, name="w3")
        w2 = weight_variable([filter_size, filter_size, features, features], stddev, name="w2")
        b1 = bias_variable([features], name="b1")
        b2 = bias_variable([features], name="b2")
        b3 = bias_variable([features], name="b3")
        conv1 = conv2d(in_node, w1, b1, keep_prob)
        conv1 = tf.layers.batch_normalization(conv1)
        tmp_h_conv = tf.nn.relu(conv1)
        conv2 = conv2dS(tmp_h_conv, w2, b2, keep_prob, 2)
        conv3 = conv2dS(in_node, w3, b3, keep_prob, 2)
        weights.append((w1, w2))
        biases.append((b1, b2))
        convs.append((conv1, conv2))
        in_node = conv2 + conv3
        in_node = tf.layers.batch_normalization(in_node)

    with tf.name_scope("conv_2"):
        features  = 16
        stddev = np.sqrt(2 / (filter_size ** 2 * features))
        w1 = weight_variable([filter_size, filter_size, features, features], stddev, name="w1")
        w2 = weight_variable([filter_size, filter_size, features, features], stddev, name="w2")
        b1 = bias_variable([features], name="b1")
        b2 = bias_variable([features], name="b2")
        conv1 = conv2d(in_node, w1, b1, keep_prob)
        conv1 = tf.layers.batch_normalization(conv1)
        tmp_h_conv = tf.nn.relu(conv1)
        conv2 = conv2d(tmp_h_conv, w2, b2, keep_prob)
        weights.append((w1, w2))
        biases.append((b1, b2))
        convs.append((conv1, conv2))
        in_node = conv2 + in_node
        in_node = tf.layers.batch_normalization(in_node)

    with tf.name_scope("conv_3"):
        features  = 32
        stddev = np.sqrt(2 / (filter_size ** 2 * features))
        w1 = weight_variable([filter_size, filter_size, features // 2, features], stddev, name="w1")
        w3 = weight_variable([filter_size, filter_size, features // 2, features], stddev, name="w3")
        w2 = weight_variable([filter_size, filter_size, features, features], stddev, name="w2")
        b1 = bias_variable([features], name="b1")
        b2 = bias_variable([features], name="b2")
        b3 = bias_variable([features], name="b3")
        conv1 = conv2d(in_node, w1, b1, keep_prob)
        conv1 = tf.layers.batch_normalization(conv1)
        tmp_h_conv = tf.nn.relu(conv1)
        conv2 = conv2dS(tmp_h_conv, w2, b2, keep_prob, 2)
        conv3 = conv2dS(in_node, w3, b3, keep_prob, 2)
        weights.append((w1, w2))
        biases.append((b1, b2))
        convs.append((conv1, conv2))
        in_node = conv2 + conv3
        in_node = tf.layers.batch_normalization(in_node)

    with tf.name_scope("conv_4"):
        features = 64
        stddev = np.sqrt(2 / (filter_size ** 2 * features))
        w1 = weight_variable([filter_size, filter_size, features // 2, features], stddev, name="w1")
        w3 = weight_variable([filter_size, filter_size, features // 2, features], stddev, name="w3")
        w2 = weight_variable([filter_size, filter_size, features, features], stddev, name="w2")
        b1 = bias_variable([features], name="b1")
        b2 = bias_variable([features], name="b2")
        b3 = bias_variable([features], name="b3")
        conv1 = conv2d(in_node, w1, b1, keep_prob)
        conv1 = tf.layers.batch_normalization(conv1)
        tmp_h_conv = tf.nn.relu(conv1)
        conv2 = conv2dS(tmp_h_conv, w2, b2, keep_prob, 1)

        # dw_h_convs[layer] = tf.nn.relu(conv2)

        conv3 = conv2dS(in_node, w3, b3, keep_prob, 1)

        weights.append((w1, w2))
        biases.append((b1, b2))
        convs.append((conv1, conv2))

        in_node = conv2 + conv3
        in_node = tf.layers.batch_normalization(in_node)

    # Output Map
    with tf.name_scope("output_map"):
        final_shape = 64
        flat_output = tf.reduce_mean(in_node, [1, 2], keep_dims=False, name='GAP')
        weight = weight_variable([final_shape, 512], stddev)
        bias = bias_variable([512], name="bias")
        fully_connected1 = tf.nn.relu(tf.add(tf.matmul(flat_output,
                                                       weight), bias))
        # Second Fully Connected Layer
        weight2 = weight_variable([512, 2], stddev)
        bias2 = bias_variable([2], name="bias")
        final_model_output = tf.add(tf.matmul(fully_connected1, weight2), bias2)

        output_map = final_model_output
        up_h_convs["out"] = output_map  # batch_size * 8 * 8 * 1

    variables = []
    for w1, w2 in weights:
        variables.append(w1)
        variables.append(w2)

    for b1, b2 in biases:
        variables.append(b1)
        variables.append(b2)

    return output_map, variables, int(in_size - size)
    
class ClassifyNet(object):
    """
    A unet implementation

    :param channels: number of channels in the input image
    :param n_class: number of output labels
    :param cost: (optional) name of the cost function. Default is 'cross_entropy'
    :param cost_kwargs: (optional) kwargs passed to the cost function. See Unet._get_cost for more options
    """

    def __init__(self, channels, n_class=1, type = 1,cost="cross_entropy", cost_kwargs={}, **kwargs):
        tf.reset_default_graph()
        self.global_step = tf.Variable(0, name="global_step",trainable=False)
        self.global_epoch1 = tf.Variable(0, name="global_epoch1",trainable=False)
        self.n_class = n_class
        self.summaries = kwargs.get("summaries", True)

        self.x = tf.placeholder("float", shape=[None, 8, 8, channels], name="x")
        self.y = tf.placeholder(shape=[None,], dtype=tf.int64,name="y")
        self.keep_prob = tf.placeholder(tf.float32, name="dropout_probability")  # dropout (keep probability)

        if type==1:
            logits, self.variables, self.offset = create_classify_net(self.x, self.keep_prob, channels, n_class,
                                                                      **kwargs)  # calling tool funciton
        elif type==4:
            logits, self.variables, self.offset = create_classify_net4(self.x, self.keep_prob, channels, n_class,
                                                                      **kwargs)  # calling tool funciton
        elif type==5:
            logits, self.variables, self.offset = create_classify_net5(self.x, self.keep_prob, channels, n_class,
                                                                       **kwargs)  # calling tool funciton
        elif type==6:
            logits,self.variables, self.offset = create_classify_net6(self.x, self.keep_prob, channels, n_class,
                                                                       **kwargs)
        elif type==9:
            logits,self.variables, self.offset = create_classify_net9(self.x, self.keep_prob, channels, n_class,
                                                                       **kwargs)
        self.cost = self._get_cost(logits, self.y)  # calling cost function
        self.correct = self._get_accuracy(logits, self.y)
        self.gradients_node = tf.gradients(self.cost, self.variables)  # get gredients

        self.gradients_x = tf.gradients(self.cost, self.x)  # get gredients

        self.gradients_signed_x = tf.sign(self.gradients_x[0])  # get gredients
        '''with tf.name_scope("cross_entropy"):
            self.cross_entropy = cross_entropy(tf.reshape(self.y, [-1, n_class]),
                                               tf.reshape(pixel_wise_softmax(logits), [-1, n_class]))'''

        with tf.name_scope("results"):
            self.predicter = logits
            self.soft_max_result = tf.nn.softmax(logits)

    def _get_cost(self, logits, y):
        """
        Constructs the cost function, either cross_entropy, weighted cross_entropy or dice_coefficient.
        Optional arguments are:
        class_weights: weights for the different classes in case of multi-class imbalance
        regularizer: power of the L2 regularizers added to the loss function
        """

        with tf.name_scope("cost"):
            # flat_logits = tf.reshape(logits, [-1, self.width, self.height])
            # flat_label = tf.reshape(self.y, [-1, self.width, self.height])
            batch_size = tf.size(y)
            labels_1 = tf.expand_dims(y,1)
            indices = tf.expand_dims(tf.range(0,batch_size,1),1)
            indices = tf.cast(indices, dtype=tf.int64)
            concated = tf.concat([indices, labels_1],1)
            onehot_labels = tf.sparse_to_dense(concated,tf.cast(tf.stack([batch_size,2]),dtype=tf.int64), 1.0, 0.0)
            class_weight = tf.constant([1.0,50.0])
            weights = tf.reduce_sum(class_weight*onehot_labels,axis=1)
            weighted_loss = (tf.nn.sparse_softmax_cross_entropy_with_logits(labels=y, logits=logits) * weights)
            loss = tf.reduce_mean(weighted_loss)
            #loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(labels=y, logits=logits))
            regularizer =  None
            if regularizer is not None:
                regularizers = sum([tf.nn.l2_loss(variable) for variable in self.variables])
                loss += (regularizer * regularizers)
            return loss

    def _get_accuracy(self,logits,y):
        soft_max_result = tf.nn.softmax(logits)
        batch_predictions = tf.argmax(soft_max_result, axis=1)
        acc = tf.reduce_mean(tf.cast(tf.equal(batch_predictions, y),dtype=tf.float32))
        return acc

    def save(self, sess, model_path):
        """
        Saves the current session to a checkpoint

        :param sess: current session
        :param model_path: path to file system location
        """
        var_list = tf.trainable_variables()
        g_list = tf.global_variables()
        bn_moving_vars = [g for g in g_list if 'moving_mean' in g.name]
        bn_moving_vars +=[g for g in g_list if 'moving_variance' in g.name]
        epoch_var = [g for g in g_list if 'epoch' in g.name]
        step_var = [g for g in g_list if 'step' in g.name]
        var_list += bn_moving_vars
        var_list +=epoch_var
        var_list += step_var
        saver = tf.train.Saver(var_list=var_list)
        for var in var_list:
            if 'epoch' in var.name:
                epoch = sess.run(var)
            if 'step' in var.name:
                step = sess.run(var)
        saver.save(sess, model_path)
        return

    def restore(self, sess, model_path):
        """
        Restores a session from a checkpoint

        :param sess: current session instance
        :param model_path: path to file system checkpoint location
        """
        var_list = tf.trainable_variables()
        g_list = tf.global_variables()
        bn_moving_vars = [g for g in g_list if 'moving_mean' in g.name]
        bn_moving_vars += [g for g in g_list if 'moving_variance' in g.name]
        epoch_var = [g for g in g_list if 'epoch' in g.name]
        step_var = [g for g in g_list if 'step' in g.name]
        var_list += bn_moving_vars
        var_list += epoch_var
        var_list += step_var
        saver = tf.train.Saver(var_list=var_list)
        for var in var_list:
            if 'epoch' in var.name:
                epoch = sess.run(var)
            if 'step' in var.name:
                step = sess.run(var)
        saver.restore(sess, model_path)
        logging.info("Model restored from file: %s" % model_path)
class Trainer(object):
    """
    Trains a unet instance

    :param net: the unet instance to train
    :param batch_size: size of training batch
    :param verification_batch_size: size of verification batch
    :param norm_grads: (optional) true if normalized gradients should be added to the summaries
    :param optimizer: (optional) name of the optimizer to use (momentum or adam)
    :param opt_kwargs: (optional) kwargs passed to the learning rate (momentum opt) and to the optimizer

    """

    def __init__(self, net, batch_size, verification_size, embedder = False, norm_grads=False, optimizer="momentum",
                 opt_kwargs={}):
        self.net = net
        self.batch_size = batch_size
        self.verification_size = verification_size
        self.norm_grads = norm_grads
        self.optimizer = optimizer
        self.opt_kwargs = opt_kwargs
        self.embedder = embedder

    def _get_optimizer(self, training_iters, global_step):
        if self.optimizer == "momentum":
            learning_rate = self.opt_kwargs.pop("learning_rate", 0.002)
            decay_rate = self.opt_kwargs.pop("decay_rate", 0.95)
            momentum = self.opt_kwargs.pop("momentum", 0.2)

            self.learning_rate_node = tf.train.exponential_decay(learning_rate=learning_rate,
                                                                 global_step=global_step,
                                                                 decay_steps=training_iters,
                                                                 decay_rate=decay_rate,
                                                                 staircase=True)

            optimizer = tf.train.MomentumOptimizer(learning_rate=self.learning_rate_node, momentum=momentum,
                                                   **self.opt_kwargs).minimize(self.net.cost,
                                                                               global_step=global_step)
        elif self.optimizer == "adam":
            learning_rate = self.opt_kwargs.pop("learning_rate", 0.001)
            self.learning_rate_node = tf.Variable(learning_rate, name="learning_rate")
            self.learning_rate_node2 = tf.train.exponential_decay(learning_rate,global_step,900*30,0.1,staircase=True)
            self.learning_rate_node = tf.train.exponential_decay(learning_rate,global_step,900*30,0.1,staircase=True)
            #self.learning_rate_node = tf.train.polynomial_decay(learning_rate,global_step,900*50,0.0001,cycle=True)
            optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate_node2,
                                               **self.opt_kwargs).minimize(self.net.cost,
                                                                           global_step=global_step)
        return optimizer

    def _initialize(self, training_iters, output_path, restore, prediction_path):

        self.norm_gradients_node = tf.Variable(tf.constant(0.0, shape=[len(self.net.gradients_node)]),
                                               name="norm_gradients")

        if self.net.summaries and self.norm_grads:
            tf.summary.histogram('norm_grads', self.norm_gradients_node)

        tf.summary.scalar('loss', self.net.cost)
        # tf.summary.scalar('cross_entropy', self.net.cross_entropy)
        # tf.summary.scalar('accuracy', self.net.accuracy)

        self.optimizer = self._get_optimizer(training_iters, self.net.global_step)
        tf.summary.scalar('learning_rate', self.learning_rate_node)

        

        tf.summary.scalar('acc',self.net.correct)

        self.summary_op = tf.summary.merge_all()

        tf.summary.scalar('loss_test', self.net.cost)
        tf.summary.scalar('accuracy_test',self.net.correct)
        merge_summary = tf.summary.merge([tf.get_collection(tf.GraphKeys.SUMMARIES,'loss_test'),tf.get_collection(tf.GraphKeys.SUMMARIES,'accuracy_test')])
        self.summary_test = merge_summary
        init = tf.global_variables_initializer()

        self.prediction_path = prediction_path
        abs_prediction_path = os.path.abspath(self.prediction_path)
        output_path = os.path.abspath(output_path)

        if not restore:
            logging.info("Removing '{:}'".format(abs_prediction_path))
            shutil.rmtree(abs_prediction_path, ignore_errors=True)
            logging.info("Removing '{:}'".format(output_path))
            shutil.rmtree(output_path, ignore_errors=True)

        if not os.path.exists(abs_prediction_path):
            logging.info("Allocating '{:}'".format(abs_prediction_path))
            os.makedirs(abs_prediction_path)

        if not os.path.exists(output_path):
            logging.info("Allocating '{:}'".format(output_path))
            os.makedirs(output_path)

        return init
    '''path = trainer.train(imageGenerator,testImageGenerator, "C:\\Users\\Xiepei\\Desktop\\epoch2\\net6\\epoch50",
                         training_iters=9000,testing_batch=100,
                         epochs=50,
                         dropout=1,  # probability to keep units
                         display_step=100,
                         restore=True)'''
    def train(self, data_provider, valid_data_provicer, output_path, training_iters=10, testing_batch=10,epochs=100, dropout=1,
              display_step=1,
              restore=False, write_graph=False, prediction_path='prediction'):  # ???dropout
        """
        Lauches the training process

        :param data_provider: callable returning training and verification data
        :param output_path: path where to store checkpoints
        :param training_iters: number of training mini batch iteration
        :param epochs: number of epochs
        :param dropout: dropout probability
        :param display_step: number of steps till outputting stats
        :param restore: Flag if previous model should be restored
        :param write_graph: Flag if the computation graph should be written as protobuf file to the output path
        :param prediction_path: path where to save predictions on each epoch
        """
        save_path = os.path.join(output_path, "model.ckpt")
        if epochs == 0:
            return save_path

        init = self._initialize(training_iters, output_path, restore, prediction_path)

        with tf.Session() as sess:
            if write_graph:
                tf.train.write_graph(sess.graph_def, output_path, "graph.pb", False)

            sess.run(init)

            if restore:
                ckpt = tf.train.get_checkpoint_state(output_path)
                if ckpt and ckpt.model_checkpoint_path:
                    self.net.restore(sess, ckpt.model_checkpoint_path)
            if not self.embedder:
                test_x, test_y = valid_data_provicer(self.verification_size)  # ?????,??????????
                start_epoch = sess.run(self.net.global_epoch1)
                start_step = sess.run(self.net.global_step)
                start_step = start_epoch * training_iters
                step_sign = tf.assign(self.net.global_step,start_step)
                sess.run(step_sign)
                summary_writer = tf.summary.FileWriter(output_path, graph=sess.graph)
                self.store_prediction(sess, test_x, test_y, testing_batch, "_init", summary_writer, start_step)  # ????loss
                logging.info("Start optimization")

                avg_gradients = None
                for epoch in range(start_epoch,epochs):  # ?????epoch
                    total_loss = 0
                    for step in range(start_step, ((epoch + 1) * training_iters)):
                        batch_x, batch_y = data_provider(self.batch_size)  # ????????batch???????
                        # Run optimization op (backprop)
                        _, loss, lr, gradients = sess.run(
                            (self.optimizer, self.net.cost, self.learning_rate_node, self.net.gradients_node),
                            feed_dict={self.net.x: batch_x,
                                       self.net.y: batch_y,
                                       self.net.keep_prob: dropout})

                        if self.net.summaries and self.norm_grads:
                            avg_gradients = _update_avg_gradients(avg_gradients, gradients, step)
                            norm_gradients = [np.linalg.norm(gradient) for gradient in avg_gradients]
                            self.norm_gradients_node.assign(norm_gradients).eval()

                        if step % display_step == 0:
                            self.output_minibatch_stats(sess, summary_writer, step, batch_x, batch_y)

                        # def output_minibatch_stats(self, sess, summary_writer, step, batch_x, batch_y):
                        total_loss += loss

                        start_step = start_step + 1

                    step_sign = tf.assign(self.net.global_step,step+1)
                    epoch_sign = tf.assign(self.net.global_epoch1,epoch+1)
                    sess.run([step_sign,epoch_sign])

                    self.output_epoch_stats(epoch, total_loss, training_iters, lr)
                    self.store_prediction(sess, test_x, test_y, testing_batch, "epoch_%s" % epoch,summary_writer, step)  # ?????Again
                    self.net.save(sess, save_path)


                logging.info("Optimization Finished!")
            else:
                summary_writer = tf.summary.FileWriter(output_path, graph=sess.graph)
                test_x, test_y = valid_data_provicer(self.verification_batch_size)  # ?????,??????????
                self.store_prediction(sess, test_x, test_y, "_init", summary_writer, 0)  # ????loss
                test_x2 = test_x
                for ii in range(80):
                    get_robsut_sign = self.get_robust_sign_value(sess, test_x2, test_y, 'test')
                    test_x2 = test_x2 + 2 * get_robsut_sign
                    test_copy = test_x2
                    test_x2 = self.to_jpeg_spatial(test_x2,self.verification_batch_size,'forspatial')
                    self.store_prediction(sess, test_x2, test_y, "_init_sign2", summary_writer, 0)  # ????loss
                self.store_result(test_x2, test_x, self.verification_batch_size, "_init")

            return save_path
    def get_accuracy(self, prediction1, targets):
        batch_predictions = np.argmax(prediction1, axis=1)
        num_correct = np.sum(np.equal(batch_predictions, targets))
        return  (100. * num_correct / batch_predictions.shape[0])
    def get_False_Alarm(self, prediction1, targets): #false alarm dose not matter
        zerosRealNum = 0
        wrongNum = 0
        batch_predictions = np.argmax(prediction1, axis=1)
        for i in range(len(batch_predictions)):
            if targets[i] == 0:
                zerosRealNum = zerosRealNum + 1
                if batch_predictions[i] == 1:
                    wrongNum = wrongNum + 1
        return  (100. * float(wrongNum) / zerosRealNum)
    def get_Miss_Detect(self, prediction1, targets):
        zerosRealNum = 0
        wrongNum = 0
        batch_predictions = np.argmax(prediction1, axis=1)
        for i in range(len(batch_predictions)):
            if targets[i] == 1:
                zerosRealNum = zerosRealNum + 1
                if batch_predictions[i] == 0:
                    wrongNum = wrongNum + 1
        return (100. * float(wrongNum) / (zerosRealNum+0.0000000000001))

    def store_prediction(self, sess, batch_x, batch_y, testing_batch_size,name,summary_writer,step):
        ite_size = int(self.verification_size / testing_batch_size)
        accuracy_array = np.zeros([ite_size,])
        loss_array = np.zeros([ite_size,])
        ms_array = np.zeros([ite_size,])
        fd_array = np.zeros([ite_size,])
        for i in range(ite_size):
            start_index = i * testing_batch_size * 4096
            end_index = (i+1) * testing_batch_size * 4096
            test_batch_temp = batch_x[start_index:end_index,:,:,:]
            test_batch_y = batch_y[start_index:end_index]
            if i==0:
                summary_str, loss, predicter, soft_result = sess.run([self.summary_test,
                                                                 self.net.cost, self.net.predicter,
                                                                 self.net.soft_max_result],
                                                                feed_dict={self.net.x: test_batch_temp,
                                                                           self.net.y: test_batch_y,
                                                                           self.net.keep_prob: 1.})
                summary_writer.add_summary(summary_str, step)
                summary_writer.flush()
                
            else:
                predicter,loss,soft_result = sess.run((self.net.predicter,self.net.cost,self.net.soft_max_result), feed_dict={self.net.x: test_batch_temp,
                                                             self.net.y: test_batch_y,
                                                             self.net.keep_prob: 1.})
            crrect_ratio = self.get_accuracy(soft_result, test_batch_y)
            accuracy_array[i] = crrect_ratio
            loss_array[i] = loss
            fa = self.get_False_Alarm(soft_result, test_batch_y)
            md = self.get_Miss_Detect(soft_result, test_batch_y)
            ms_array[i] = md
            fd_array[i] = fa

        accucacy_average = np.average(accuracy_array)
        loss_average = np.average(loss_array)
        ms_average = np.average(ms_array)
        fd_average = np.average(fd_array)

        
        logging.info("Verification loss= {:.4f}".format(loss_average))
        logging.info("Verification correct ratio = {:.4f}%".format(accucacy_average))
        logging.info("Verification get_False_Alarm ratio = {:.4f}%".format(fd_average))
        logging.info("Verification get_Miss_Detect ratio = {:.4f}%".format(ms_average))



    def output_epoch_stats(self, epoch, total_loss, training_iters, lr):
        logging.info(
            "Epoch {:}, Average loss: {:.4f}, learning rate: {:.4f}".format(epoch, (total_loss / training_iters), lr))

    def output_minibatch_stats(self, sess, summary_writer, step, batch_x, batch_y):
        # Calculate batch loss and accuracy
        summary_str, loss, pred,soft_result = sess.run([self.summary_op,
                                            self.net.cost, self.net.predicter,self.net.soft_max_result],
                                           feed_dict={self.net.x: batch_x,
                                                      self.net.y: batch_y,
                                                      self.net.keep_prob: 1.})
        summary_writer.add_summary(summary_str, step)
        summary_writer.flush()
        logging.info("Iter {:}, Minibatch Loss= {:.4f}".format(step, loss))


        crrect_ratio = self.get_accuracy(soft_result, batch_y)
        logging.info("Iter {:}, train correct ratio = {:.4f}%".format(step,crrect_ratio))

        crrect_ratio = self.get_False_Alarm(soft_result, batch_y)
        logging.info("Iter {:}, train  get_False_Alarm ratio = {:.4f}%".format(step,crrect_ratio))
        crrect_ratio = self.get_Miss_Detect(soft_result, batch_y)
        logging.info("Iter {:}, train  get_Miss_Detect ratio = {:.4f}%".format(step,crrect_ratio))

    def get_sign_value(self, sess, test_x, test_y, param):
        gradients_signed_x  = sess.run(self.net.gradients_signed_x,feed_dict={self.net.x: test_x,\
                                                           self.net.y: test_y,\
                                                           self.net.keep_prob: 1.})
        return gradients_signed_x

    def get_robust_sign_value(self, sess, test_x, test_y, param):
        gradients_signed_x,gradients_x = sess.run((self.net.gradients_signed_x,self.net.gradients_x), feed_dict={self.net.x: test_x, \
                                                                              self.net.y: test_y, \
                                                                              self.net.keep_prob: 1.})
        new_result = np.zeros(gradients_signed_x.shape)
        for i in range(new_result.shape[0]):
            temp_img = gradients_signed_x[i]
            if test_y[i]!=0:
                new_result[i] = temp_img
        return new_result

    def store_result(self, test_x2,test_x, verification_batch_size, name):
        index = 0
        result_1 = np.zeros((verification_batch_size, 512, 512))
        result_2 = np.zeros((verification_batch_size,512,512))
        for i in range(verification_batch_size):
            for ii in range(64):
                for jj in range(64):
                    block = test_x2[index,:,:,0]
                    result_2[i,ii*8:ii*8+8,jj*8:jj*8+8] = block
                    block = test_x[index, :, :, 0]
                    result_1[i, ii * 8:ii * 8 + 8, jj * 8:jj * 8 + 8] = block
                    index = index + 1
            fileNameSrc = self.prediction_path + "/" + name + str(i)+ '_before.mat'
            fileNamePre = self.prediction_path + "/" + name + str(i)+ '_after.mat'
            scio.savemat(fileNameSrc, {'spatial': result_1[i]})
            scio.savemat(fileNamePre, {'spatial': result_2[i]})

    def to_jpeg_spatial(self, test_x2, verification_batch_size, name):
        index = 0
        index2 = 0
        result_1 = np.zeros((verification_batch_size, 512, 512))
        return_1 = np.zeros(test_x2.shape)
        for i in range(verification_batch_size):
            for ii in range(64):
                for jj in range(64):
                    block = test_x2[index, :, :, 0]
                    result_1[i, ii * 8:ii * 8 + 8, jj * 8:jj * 8 + 8] = block
                    index = index + 1
            fileNameSrc = self.prediction_path + "/" + name + str(i) + '_temp.mat'
            scio.savemat(fileNameSrc, {'spatial': result_1[i]})
            cmdStr = 'F:/syncMac/matlab/compressAndDecompress.exe ' + fileNameSrc + ' temp.mat'\
                                                    + ' 85'
            result = os.system(cmdStr)
            spatial2 = scio.loadmat('temp.mat')['spatial']

            for ii in range(64):
                for jj in range(64):
                    block = spatial2[ii * 8:ii * 8 + 8, jj * 8:jj * 8 + 8]
                    return_1[index2,:,:,0] = block
                    index2 = index2 + 1

        return return_1

        


def _update_avg_gradients(avg_gradients, gradients, step):
    if avg_gradients is None:
        avg_gradients = [np.zeros_like(gradient) for gradient in gradients]
    for i in range(len(gradients)):
        avg_gradients[i] = (avg_gradients[i] * (1.0 - (1.0 / (step + 1)))) + (gradients[i] / (step + 1))

    return avg_gradients


def error_rate(predictions, labels):
    """
    Return the error rate based on dense predictions and 1-hot labels.
    """

    return 100.0 - (
            100.0 *
            np.sum(np.argmax(predictions, 3) == np.argmax(labels, 3)) /
            (predictions.shape[0] * predictions.shape[1] * predictions.shape[2]))


def get_image_summary(img, idx=0):
    """
    Make an image summary for 4d tensor image with index idx
    """

    V = tf.slice(img, (0, 0, 0, idx), (1, -1, -1, 1))
    V -= tf.reduce_min(V)
    V /= tf.reduce_max(V)
    V *= 255

    img_w = tf.shape(img)[1]
    img_h = tf.shape(img)[2]
    V = tf.reshape(V, tf.stack((img_w, img_h, 1)))
    V = tf.transpose(V, (2, 0, 1))
    V = tf.reshape(V, tf.stack((-1, img_w, img_h, 1)))
    return V
