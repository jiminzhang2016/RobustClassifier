function [ratio,distortion_all] = EmbedWithProtocolAllNewV6FullPayloads(jpegName,coverName, stegoName,recordfile,maxphase, seed, qf, max_change)
addpath('cost','STCTool');
randkey = 12345;
jpeg_struct = jpeg_read(jpegName);
%??????????
jpeg_dct = jpeg_struct.coef_arrays{1};
[jpeg_h, jpeg_w] = size(jpeg_dct);
quant_table = jpeg_struct.quant_tables{1};
jpeg_dct_old = jpeg_dct;
fid = fopen(recordfile,'a');
fprintf(fid,['fileName:',jpegName,'\n']);
%????????
num_block = 4096;
rng(123456);
rand_num = randperm(4096);
ratio = ones([1,5]);
ratio = ratio - 1;
distortion_all = zeros([1,5]);
embed_for_msg = rand_num(1 : 4096/2);
embed_for_protocol = rand_num(4096/2 + 1 : 4096); %location for embedding protocol
msg_img = zeros([8, 2048 * 8]);
protocol_img = zeros([8, 2048 * 8]);
%??????1???
%??????
index = 1;
for_show = 0;
protocol_img_index = 1;
msg_img_index = 1;
for i = 1 : 8 : 512
    for j = 1 : 8 : 512
        dct_block = jpeg_dct(i : i + 7, j : j + 7);
        if nnz((index == embed_for_msg))>0
            msg_img(1 : 8, ((msg_img_index - 1) * 8 + 1) : (msg_img_index) * 8) = dct_block; %?????????            
            if(for_show==1)
                block_temp = dct_block;
                img_content = uint8(idct2(block_temp .* quant_table)+128);
                
            end
            msg_index_array(msg_img_index) = index;
            msg_img_index = msg_img_index + 1;
        else
            protocol_img(1 : 8, ((protocol_img_index - 1) * 8 + 1) : (protocol_img_index) * 8) = dct_block; %?????????
            if(for_show==1)
                block_temp = dct_block;
                img_content = uint8(idct2(block_temp .* quant_table)+128);
                
            end
            protocol_index_array(protocol_img_index) = index;
            protocol_img_index = protocol_img_index + 1;
        end  
        index = index + 1;
    end
end

block_num_protocol = protocol_img_index - 1;
block_num_msg = msg_img_index - 1;
hist_result = zeros([1, 100]);
for i = 1 : block_num_protocol
    block_dct = protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
    nznum = 0;
    for ii = 1 : 8
        for jj = 1 : 8
            if (ii + jj) > 6 && (ii + jj) < 10
                if abs(block_dct(ii, jj)) > 1
                    nznum = nznum + 1;
                end
            end
        end
    end
    if(nznum > 0)
        hist_result(uint8(nznum)) =  hist_result(uint8(nznum)) + 1; %?0??????
    end
end
%???????
all_num = 0;
n = 0;
for i = 100 : -1 : 1
    all_num = hist_result(i) + all_num;
    if all_num > 661
        n = i;
    	break;
    end
    
end
old_n = n;
if(n<3)
    fprintf(fid, 'sorry, need n above 3 \n');
    return;
end


[rhoP1J, rhoM1J] = J_UNIWARD(jpegName);
[robustP11,robustM11,cost_plus1,cost_minus1,selfP] = robust_cost_python(jpegName,  10, seed, qf);
msg_img_rho_p1 = zeros([8, 2048 * 8]);
msg_img_rho_m1 = zeros([8, 2048 * 8]);
protocol_img_rho_p1 = zeros([8, 2048 * 8]);
protocol_img_rho_m1 = zeros([8, 2048 * 8]);
 
msg_img_index = 1;
protocol_img_index = 1;
index = 1;
jpeg_dct = jpeg_struct.coef_arrays{1};
quant_table = jpeg_struct.quant_tables{1};

for i = 1 : 8 : 512
    for j = 1 : 8 : 512
        dct_block = jpeg_dct(i : i + 7, j : j + 7);
        block_rho_p1 = rhoP1J(i : i + 7, j : j + 7);
        block_rho_m1 = rhoM1J(i : i + 7, j : j + 7);
       
        self_block = selfP(i : i + 7, j : j + 7);
        if nnz((index == embed_for_msg))>0
            msg_img(1 : 8, ((msg_img_index - 1) * 8 + 1) : (msg_img_index) * 8) = dct_block; %?????????
            msg_img_rho_p1(1 : 8, ((msg_img_index - 1) * 8 + 1) : (msg_img_index) * 8) =  block_rho_p1;
            msg_img_rho_m1(1 : 8, ((msg_img_index - 1) * 8 + 1) : (msg_img_index) * 8) =  block_rho_m1;
            msg_img_robust_p(1 : 8, ((msg_img_index - 1) * 8 + 1) : (msg_img_index) * 8) =  self_block;
            msg_img_index = msg_img_index + 1;
        else
            protocol_img(1 : 8, ((protocol_img_index - 1) * 8 + 1) : (protocol_img_index) * 8) = dct_block; %?????????
            protocol_img_rho_p1(1 : 8, ((protocol_img_index - 1) * 8 + 1) : (protocol_img_index) * 8) =  block_rho_p1;
            protocol_img_rho_m1(1 : 8, ((protocol_img_index - 1) * 8 + 1) : (protocol_img_index) * 8) =  block_rho_m1;
            protocol_img_rho_self(1 : 8, ((protocol_img_index - 1) * 8 + 1) : (protocol_img_index) * 8) =  self_block;
            protocol_img_index = protocol_img_index + 1;
        end  
        index = index + 1;
    end
end

%%
%%???????protocol_img
rng(123456);
randpermed_protocl = randperm(block_num_protocol);
permed_protocol_img = zeros([8, block_num_protocol]);
permed_rho_p1 = zeros([8, block_num_protocol]);
permed_rho_m1 = zeros([8, block_num_protocol]);
permed_rho_self = zeros([8, block_num_protocol]);
for i = 1 : block_num_protocol
    permed_protocol_img(1:8, (i-1)*8+1:i*8) = protocol_img(1 : 8, ((randpermed_protocl(i) - 1) * 8 + 1) : (randpermed_protocl(i)) * 8);
    permed_rho_p1(1:8, (i-1)*8+1:i*8) = protocol_img_rho_p1(1 : 8, ((randpermed_protocl(i) - 1) * 8 + 1) : (randpermed_protocl(i)) * 8); 
    permed_rho_m1(1:8, (i-1)*8+1:i*8) = protocol_img_rho_m1(1 : 8, ((randpermed_protocl(i) - 1) * 8 + 1) : (randpermed_protocl(i)) * 8);
    permed_rho_self(1:8, (i-1)*8+1:i*8) = protocol_img_rho_self(1 : 8, ((randpermed_protocl(i) - 1) * 8 + 1) : (randpermed_protocl(i)) * 8);
end
protocol_img = permed_protocol_img;
protocol_img_rho_p1 = permed_rho_p1;
protocol_img_rho_m1 = permed_rho_m1;
protocol_img_rho_self = permed_rho_self;
%%
block_num = zeros([1, 661]);
new_protocol_img = zeros([8, 661 * 8]);
index = 1;
index2 = 1;
all_index = 1;
last_find_index = 0;
all_changed_index = 1;
for i = 1 : block_num_protocol
    block_dct = protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
    %???????
    block_rho_p1 = protocol_img_rho_p1(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
    block_rho_m1 = protocol_img_rho_m1(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
    nznum = 0;
    for ii = 1 : 8
        for jj = 1 : 8
            if (ii + jj) > 6 && (ii + jj) < 10
                if abs(block_dct(ii, jj)) > 1
                    nznum = nznum + 1;
                end
            end
        end
    end
    all_index_array(i) = nznum;
    if(nznum >= n && index <662)
        if(index == 661)
            last_find_index = i;
        end
        nznum_array(index) = nznum;
        block_num(index) = i; %the real block used for embedding
        all_changed_index_array(all_changed_index) = i;
        all_changed_index = all_changed_index + 1;
        new_protocol_img(1:8, (index - 1) * 8 + 1 : index * 8) = block_dct;
        new_block_rho_p1(1:8, (index - 1) * 8 + 1 : index * 8) = block_rho_p1;
        new_block_rho_m1(1:8, (index - 1) * 8 + 1 : index * 8) = block_rho_m1;   
        index = index + 1;
    end
end
new_len = index - 1;

zeros_index = 1;
for i=1:block_num_msg
    block_temp = msg_img_robust_p(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
    real_temp = msg_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
    cost_temp_p1 = msg_img_rho_p1(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
    cost_temp_m1 = msg_img_rho_m1(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
    if block_temp(1,1)>=0.5
        sequence(i) = 1;
        if(for_show==1)
                block_temp2 = real_temp;
                img_content = uint8(idct2(block_temp2 .* quant_table)+128);
                
        end
    else
        sequence(i) = 0; %???????????
        robust_block(1 : 8,(zeros_index - 1) * 8 + 1 : zeros_index * 8) = real_temp;
        rhoP1Real_robust_block(1:8, (zeros_index-1)*8+1:zeros_index*8) = cost_temp_p1;
        rhoM1Real_robust_block(1:8, (zeros_index-1)*8+1:zeros_index*8) = cost_temp_m1;
        zeros_index = zeros_index + 1;
        if(for_show==1)
                block_temp2 = real_temp;
                img_content = uint8(idct2(block_temp2 .* quant_table)+128);
                
        end
    end
end

%%
%generate stego image for msg%
size_msg = size(robust_block);
payloads_array = [0.05, 0.1, 0.2, 0.3];
jpeg_pre_embedding = cell([4,1]);
jpeg_embed_number = cell([4,1]);
perm_array = cell([4,1]);
msg_array = cell([4,1]);
strim_array = cell([4,1]);
embed_rand_path_array = cell([4,1]);
jpeg_dct_old = jpeg_dct;
robust_block_old = robust_block;
for alli=1:4
    robust_block = robust_block_old;
    jpeg_dct = jpeg_dct_old;
    payload = payloads_array(alli);
    nznum1 = floor(payload*(nnz(jpeg_dct_old) - nnz(jpeg_dct_old(1:8:jpeg_h, 1:8:jpeg_w) )));
    nznum2 = floor(0.5* size_msg(1) * size_msg(2));
    nznum = min(nznum1, nznum2);
    if(nznum == nznum2)
        fprintf(fid, 'the robust image is too small, actually %d message is embeded \n', nznum2 );
    end
    bch_n = 127;
    bch_k = 64;
    msg_len = round(nznum / bch_n) * bch_k;
    if(msg_len == 0)
        msg_len = 1;
    end
    msg_embeded = uint8(round(rand([1, msg_len])));
    padd = ceil(length(msg_embeded)/bch_k)*bch_k-length(msg_embeded);
    strimm=[msg_embeded zeros(1,padd)];
    strim_array{alli} = strimm;
    enc=comm.BCHEncoder(bch_n,bch_k);  
    msg=step(enc,strimm.');
    length_msg = length(msg);
    rng(randkey);
    perm_msg_index = randperm(length_msg);
    perm_array{alli} = perm_msg_index;
    perm_msg = msg(perm_msg_index);
    msg_new = perm_msg;
    msg = msg_new; 
    msg_array{alli} = msg;
    cover_len = size_msg(1)* size_msg(2);
    embed_rand_path = randperm(cover_len);
    embed_rand_path_array{alli} = embed_rand_path;
    try
        [stego_real,n_msg_bits,D] = stc_embed_tenary(robust_block,rhoP1Real_robust_block,rhoM1Real_robust_block,7,msg,embed_rand_path);
    catch
        fprintf(fid,['Embed failed\n']);
        return;
    end
    for i=1:8:size_msg(1)
        for j=1:8:size_msg(2)
            dct_block = stego_real(i:i+7, j:j+7);
            robust_block(i:i+7, j:j+7) = dct_block;
        end
    end
    before_embedding_dct = jpeg_dct_old;
    index = 1;
    index2 = 1;
    zero_index = 1;
    for i = 1:8:512
        for j=1:8:512
            if nnz((index == embed_for_msg))>0
                if sequence(index2) == 0
                    jpeg_dct(i : i + 7, j : j + 7) = robust_block(1:8, (zero_index-1)*8+1:zero_index*8);
                    zero_index = zero_index + 1;
                end
                index2 = index2 + 1;
            end
            index = index + 1;
        end
    end
    jpeg_pre_embedding{alli} = jpeg_dct;
    jpeg_embed_number{alli} = n_msg_bits;
end

%%
n_msg_bits_bin_1 = dec2binvec(double(n_msg_bits(1)), 16);
old_len = length(sequence);
for i = 1:16
    sequence(old_len+i) = n_msg_bits_bin_1(i);
end
n_msg_bits_bin_2 = dec2binvec(double(n_msg_bits(2)), 16);
old_len = length(sequence);
for i = 1:16
    sequence(old_len+i) = n_msg_bits_bin_2(i);
end
%CRC cali to sequence
crc32 = crc32_adler(0, sequence);
crcbin = dec2binvec(double(crc32));
len_bin = length(crcbin);
crcbin = [crcbin, zeros([1,32-len_bin])];
sequence = [sequence,zeros([1,32])]; 
len = length(sequence);
sequence(len-31:len) = crcbin;
%?sequence????
robust_p1 = zeros([8, 661 * 8]);
robust_m1 = zeros([8, 661 * 8]);
looper = 1;
while looper
    jpeg_dct_stego = new_protocol_img;
    %jpeg_dct_stego = new_protocol_img;
    index = 1;
    all_index = 1;
    for i = 1 : new_len
        if i==3
            iiii=1;
        end
        block_dct = jpeg_dct_stego(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        block_dct_before = new_protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        block_rho_p1_before = new_block_rho_p1(1:8, (i - 1) * 8 + 1 : i * 8);
        copy_p1 = block_rho_p1_before;
       
        nznum = 0;
        for ii = 1 : 8
            for jj = 1 : 8
                if (ii + jj) > 6 && (ii + jj) < 10
                    if abs(block_dct(ii, jj)) > 1
                        nznum = nznum + 1;
                    end
                end
            end
        end
        nznum_before = 0;
        for ii = 1 : 8
            for jj = 1 : 8
                if (ii + jj) > 6 && (ii + jj) < 10
                    if abs(block_dct_before(ii, jj)) > 1
                        nznum_before = nznum_before + 1;
                    end
                end
            end
        end
        nznum_array(i) = nznum;
        %change n to n + 2
        change_num = 0;
        if(nznum == n)
            diff = block_dct_before - block_dct;
            block_rho_p1_before(diff~=0) = inf;
            for ii = 1 : 8
                    for jj = 1 : 8
                        if (ii+jj<7 || ii + jj > 9)
                            block_rho_p1_before(ii, jj) = inf;
                        end
                    end
            end
            block_rho_p1_before_copy = block_rho_p1_before;
            one_num = 0;
            for ii = 1 : 8
                    for jj = 1 : 8
                        if (ii+jj>6 && ii + jj < 10)
                            if(abs(block_dct_before(ii, jj)) == 1)
                                if(block_rho_p1_before(ii, jj) ~= inf)
                                    one_num = one_num + 1;
                                end
                            end
                        end
                    end
            end
            loop_flag  = 1;
            while loop_flag == 1
                    max_rho = max(block_rho_p1_before(:));
                    min_rho = min(block_rho_p1_before(:));
                    [xx, yy] = find(block_rho_p1_before == min_rho);
                    if length(xx) > 1
                        xx = xx(1);
                        yy = yy(1);
                    end
                    if(xx==1 && yy == 1)
                        loop_flag = 0;
                    end
                    if(xx + yy > 6 && xx + yy < 10)
                        if(one_num == 0)
                            if(block_dct_before(xx, yy) == 0)
                                if(rand()>0.5)
                                    block_dct_before(xx, yy) = 2;
                                    change_num = change_num + 1;
                                    if(change_num == 2)
                                        loop_flag = 0;
                                    end
                                else
                                    block_dct_before(xx, yy) = -2;
                                    change_num = change_num + 1;
                                    if(change_num == 2)
                                        loop_flag = 0;
                                    end
                                end
                            end    
                        end
                        value = block_dct(xx, yy);
                        if( value == 1)
                            block_dct_before(xx, yy) = 2;
                            block_rho_p1_before(xx, yy) = max_rho;
                            change_num = change_num + 1;
                            one_num = one_num - 1;
                            if(one_num==0)
                                block_rho_p1_before(abs(block_dct_before)~=2) = block_rho_p1_before_copy(abs(block_dct_before)~=2);
                            end
                            if(change_num == 2)
                                loop_flag = 0;
                            end
                        elseif(value == -1)
                            block_dct_before(xx, yy) = -2;
                            block_rho_p1_before(xx, yy) = max_rho;
                            change_num = change_num + 1;
                            one_num = one_num - 1;
                            if(one_num==0)
                                block_rho_p1_before(abs(block_dct_before)~=2) = block_rho_p1_before_copy(abs(block_dct_before)~=2);
                            end
                            if(change_num == 2)
                                loop_flag = 0;
                            end
                        else
                            block_rho_p1_before(xx, yy) = max_rho;
                        end
                    else
                        block_rho_p1_before(xx, yy) = max_rho;
                    end   
            end
            new_protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8) = block_dct_before;
        end
        %change n+1 to n+2
        change_num = 0;
        if(nznum == n + 1)
            diff = block_dct_before - block_dct;
            block_rho_p1_before(diff~=0) = inf;
            for ii = 1 : 8
                    for jj = 1 : 8
                        if (ii+jj<7 || ii + jj > 9)
                            block_rho_p1_before(ii, jj) = inf;

                        end
                    end
            end
            one_num = 0;
            for ii = 1 : 8
                    for jj = 1 : 8
                        if (ii+jj>6 && ii + jj < 10)
                            if(abs(block_dct_before(ii, jj)) == 1)
                                if(block_rho_p1_before(ii, jj) ~= inf)
                                    one_num = one_num + 1;
                                end
                            end
                        end
                    end
            end
            loop_flag  = 1;
            while loop_flag == 1
                    max_rho = max(block_rho_p1_before(:));
                    min_rho = min(block_rho_p1_before(:));
                    [xx, yy] = find(block_rho_p1_before == min_rho);
                    if length(xx) > 1
                        xx = xx(1);
                        yy = yy(1);
                    end
                    if(xx==1 && yy == 1)
                        loop_flag = 0;
                    end
                    if(xx + yy > 6 && xx + yy < 10)
                        if(one_num == 0)
                            if(block_dct_before(xx, yy) == 0)
                                if(rand()>0.5)
                                    block_dct_before(xx, yy) = 2;
                                    change_num = change_num + 1;
                                    if(change_num == 1)
                                        loop_flag = 0;
                                    end
                                else
                                    block_dct_before(xx, yy) = -2;
                                    change_num = change_num + 1;
                                    if(change_num == 1)
                                        loop_flag = 0;
                                    end
                                end
                            end    
                        end
                        value = block_dct(xx, yy);
                        if( value == 1)
                            block_dct_before(xx, yy) = 2;
                            change_num = change_num + 1;
                            if(change_num == 1)
                                loop_flag = 0;
                            end
                        elseif(value == -1)
                            block_dct_before(xx, yy) = -2;
                            change_num = change_num + 1;
                            if(change_num == 1)
                                loop_flag = 0;
                            end
                        else
                            block_rho_p1_before(xx, yy) = max_rho;
                        end
                    else
                        block_rho_p1_before(xx, yy) = max_rho;
                    end   
            end
            new_protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8) = block_dct_before;
        end
    end
    %%perform protocol information embedding
    
    for i = 1 : new_len
        block_dct = jpeg_dct_stego(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        block_dct_before = new_protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        block_rho_p1_before = new_block_rho_p1(1:8, (i - 1) * 8 + 1 : i * 8);
        copy_p1 = block_rho_p1_before;
        nznum = 0;
        for ii = 1 : 8
            for jj = 1 : 8
                if (ii + jj) > 6 && (ii + jj) < 10
                    if abs(block_dct(ii, jj)) > 1
                        nznum = nznum + 1;
                    end
                end
            end
        end
        nznum_before = 0;
        for ii = 1 : 8
            for jj = 1 : 8
                if (ii + jj) > 6 && (ii + jj) < 10
                    if abs(block_dct_before(ii, jj)) > 1
                        nznum_before = nznum_before + 1;
                    end
                end
            end
        end
        nznum_array2(i) = nznum;
    end
    if (nnz(nznum_array2==n)==0 && nnz(nznum_array2==n+1)==0)
         looper = 0;
    end
    %stego image is the image that after n to n + 2 and stego embedding
end
for i=1:length(all_changed_index_array)
    block_temp = new_protocol_img(1 : 8, (((i) - 1) * 8 + 1) : ((i)) * 8);
    protocol_img(1 : 8, ((all_changed_index_array(i) - 1) * 8 + 1) : (all_changed_index_array(i)) * 8) = block_temp;
end
    



%look at n-1 to n-3
looper = 1;
all_changed_number = 0;
while looper
    for i = 1 : last_find_index
        if( i ==188 )
            test = i;
        end
        block_dct_before = protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        %???????block_rho_p1_before = new_block_rho_p1(1:8, (index - 1) * 8 + 1 : index * 8);
        block_rho_p1 = protocol_img_rho_p1(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        block_rho_self = protocol_img_rho_self(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        nznum = 0;
        abs2_num  = 0;

        for ii = 1 : 8
            for jj = 1 : 8
                if (ii+jj<7 || ii + jj > 9)
                    block_rho_p1(ii, jj) = inf;
                end
            end
        end
        block_rho_p1_copy = block_rho_p1;
        for ii = 1 : 8
            for jj = 1 : 8
                if (ii + jj) > 6 && (ii + jj) < 10
                    if abs(block_dct_before(ii, jj)) > 1
                        if(abs(block_dct_before(ii, jj)) == 2)
                            abs2_num = abs2_num + 1;
                        end
                        nznum = nznum + 1;
                    end
                end
            end
        end
        change_num = 0;
        loop_flag = 1;

        if(n-3 >= 0)
            %change n - 1 to n - 3 
            if(nznum == n - 3)
                if( block_rho_self(1,1) > 0.5 )
                    all_changed_index_array(all_changed_index) = i;
                    all_changed_index = all_changed_index + 1;
                end
            end
            if (nznum == n - 1)
                if( block_rho_self(1,1) > 0.5 )
                    all_changed_index_array(all_changed_index) = i;
                    all_changed_index = all_changed_index + 1;
                end
                while loop_flag == 1

                        max_rho = max(block_rho_p1(:));
                        min_rho = min(block_rho_p1(:));
                        [xx, yy] = find(block_rho_p1 == min_rho);
                        if length(xx) > 1
                            xx = xx(1);
                            yy = yy(1);
                        end
                        if(xx==1 && yy == 1)
                            loop_flag = 0;
                        end
                        if(xx + yy > 6 && xx + yy < 10)

                            value = block_dct_before(xx, yy);
                            if(abs2_num == 0)
                                if (value > 1 )
                                    block_dct_before(xx, yy) = 1;
                                    change_num = change_num + 1;
                                    if(change_num == 2)
                                        loop_flag = 0;
                                    end
                                elseif(value < -1 )
                                    block_dct_before(xx, yy) = -1;
                                    change_num = change_num + 1;
                                    if(change_num == 2)
                                        loop_flag = 0;
                                    end
                                else

                                end
                            end
                            if( value == 2)
                                block_dct_before(xx, yy) = 1;
                                block_rho_p1(xx, yy) = max_rho;
                                change_num = change_num + 1;
                                abs2_num = abs2_num - 1;
                                if(abs2_num == 0)
                                    block_rho_p1(abs(block_dct_before)~=1) = block_rho_p1_copy(abs(block_dct_before)~=1);
                                end
                                if(change_num == 2)
                                    loop_flag = 0;
                                end
                            elseif(value == -2)
                                block_dct_before(xx, yy) = -1;
                                block_rho_p1(xx, yy) = max_rho;
                                change_num = change_num + 1;
                                abs2_num = abs2_num - 1;
                                if(abs2_num == 0)
                                    block_rho_p1(abs(block_dct_before)~=1) = block_rho_p1_copy(abs(block_dct_before)~=1);
                                end
                                if(change_num == 2)
                                    loop_flag = 0;
                                end
                            else
                                block_rho_p1(xx, yy) = max_rho;
                            end
                        else
                            block_rho_p1(xx, yy) = max_rho;
                        end   
                end
                protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8) = block_dct_before;
            end
            if (nznum == n - 2)
                if( block_rho_self(1,1) > 0.5 )
                    all_changed_index_array(all_changed_index) = i;
                    all_changed_index = all_changed_index + 1;
                end
                while loop_flag == 1

                        max_rho = max(block_rho_p1(:));
                        min_rho = min(block_rho_p1(:));
                        [xx, yy] = find(block_rho_p1 == min_rho);
                        if length(xx) > 1
                            xx = xx(1);
                            yy = yy(1);
                        end
                        if(xx==1 && yy == 1)
                            loop_flag = 0;
                        end
                        if(xx + yy > 6 && xx + yy < 10)

                            value = block_dct_before(xx, yy);
                            if(abs2_num == 0)
                                if (value > 1 )
                                    block_dct_before(xx, yy) = 1;
                                    change_num = change_num + 1;
                                    if(change_num == 1)
                                        loop_flag = 0;
                                    end
                                elseif(value < -1 )
                                    block_dct_before(xx, yy) = -1;
                                    change_num = change_num + 1;
                                    if(change_num == 1)
                                        loop_flag = 0;
                                    end
                                else   


                                end
                            end
                            if( value == 2)
                                block_dct_before(xx, yy) = 1;
                                change_num = change_num + 1;
                                block_rho_p1(xx, yy) = max_rho;
                                abs2_num = abs2_num - 1;
                                if(abs2_num == 0)
                                    block_rho_p1(abs(block_dct_before)~=1) = block_rho_p1_copy(abs(block_dct_before)~=1);
                                end
                                if(change_num == 1)
                                    loop_flag = 0;
                                end
                            elseif(value == -2)
                                block_dct_before(xx, yy) = -1;
                                change_num = change_num + 1;
                                abs2_num = abs2_num - 1;
                                block_rho_p1(xx, yy) = max_rho;
                                if(abs2_num == 0)
                                    block_rho_p1(abs(block_dct_before)~=1) = block_rho_p1_copy(abs(block_dct_before)~=1);
                                end
                                if(change_num == 1)
                                    loop_flag = 0;
                                end
                            else
                                block_rho_p1(xx, yy) = max_rho;
                            end
                        else
                            block_rho_p1(xx, yy) = max_rho;
                        end   
                end
                protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8) = block_dct_before;
            end
        end
    end
    for i = 1 : last_find_index
        block_dct_before = protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        %???????block_rho_p1_before = new_block_rho_p1(1:8, (index - 1) * 8 + 1 : index * 8);
        block_rho_p1 = protocol_img_rho_p1(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
        nznum = 0;
        abs2_num  = 0;

        for ii = 1 : 8
            for jj = 1 : 8
                if (ii+jj<7 || ii + jj > 9)
                    block_rho_p1(ii, jj) = inf;
                end
            end
        end
        for ii = 1 : 8
            for jj = 1 : 8
                if (ii + jj) > 6 && (ii + jj) < 10
                    if abs(block_dct_before(ii, jj)) > 1
                        if(abs(block_dct_before(ii, jj)) == 2)
                            abs2_num = abs2_num + 1;
                        end
                        nznum = nznum + 1;
                    end
                end
            end
        end
        new_nznum_array(i)=nznum;
    end
    if(length(find(new_nznum_array==n-2))==0 && length(find(new_nznum_array==n-1))==0)
        looper = 0;
    end
end
%change the n-1 and n-2 to n-3 in protocol_img
%write the file in jpeg file

%perform robust embedding to jpeg_dct_stego
for i=1:length(all_changed_index_array)
    block_temp = protocol_img(1 : 8, ((all_changed_index_array(i) - 1) * 8 + 1) : (all_changed_index_array(i)) * 8);
    block_p1_array(1 : 8, ((i - 1) * 8 + 1) : (i) * 8) = protocol_img_rho_p1(1 : 8, ((all_changed_index_array(i) - 1) * 8 + 1) : (all_changed_index_array(i)) * 8);
    block_m1_array(1 : 8, ((i - 1) * 8 + 1) : (i) * 8) = protocol_img_rho_m1(1 : 8, ((all_changed_index_array(i) - 1) * 8 + 1) : (all_changed_index_array(i)) * 8);
    need_robust(1 : 8, ((i - 1) * 8 + 1) : (i) * 8) = block_temp;
end

old_need_robust = need_robust;
protocol_img_backup = protocol_img;
for times = 1:5
        [change_possibility_p1,change_possibility_m1,change_possibility_p2,change_possibility_m2,  ...
                change_possibility_p3,change_possibility_m3,change_possibility_p4,change_possibility_m4,change_possibility_p5,change_possibility_m5,...
                distortion,cost_plus1,cost_minus1,cost_self_old,cost_plus2,cost_minus2,cost_plus3,cost_minus3,cost_plus4,cost_minus4,cost_plus5,...
                cost_minus5] = flip_possibility_test_distortion_old(need_robust, quant_table,length(all_changed_index_array),seed,qf,block_p1_array,block_m1_array,old_need_robust, maxphase,max_change, 1);
        above_5_number = 0;
        for i=1: length(all_changed_index_array)
            block_temp_possibility(i) = cost_self_old(1, (i - 1) * 8 + 1);
            if(block_temp_possibility(i)>=0.5)
                above_5_number = above_5_number + 1;
            end
        end
        avg_poss = mean(block_temp_possibility(:));
        fprintf(fid, 'the mean of non-robustness possibility of last time is  %f \n',avg_poss);
        above5Num = above_5_number / length(block_temp_possibility);
        fprintf(fid, 'the ratio above 0.5 in last image is   %f \n',above5Num);
        if(avg_poss<0.25)
            if(times>2)
                break;
            end
        end
        jpeg_dct_stego2 = need_robust;
        jpeg_dct_new = jpeg_dct_stego2;
        poss_map = cost_self_old;
        [sizeh, sizew] = size(need_robust);
        for i=1:sizeh
            for j=1:sizew
                if j>=((666 - 1) * 8 + 1) && j<=((666 * 8))
                    testiii = 1;
                end
                if(change_possibility_p1(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) + 1;
                     poss_map(i,j) = cost_plus1(i,j);
                end
                if(change_possibility_m1(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) - 1;
                    poss_map(i,j) = cost_minus1(i,j);
                end
                if(change_possibility_p2(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) + 2;
                    poss_map(i,j) = cost_plus2(i,j);
                end
                if(change_possibility_m2(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) - 2;
                    poss_map(i,j) = cost_minus2(i,j);
                end
                if(change_possibility_p3(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) + 3;
                    poss_map(i,j) = cost_plus3(i,j);
                end
                if(change_possibility_m3(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) - 3;
                    poss_map(i,j) = cost_minus3(i,j);
                end
                if(change_possibility_p4(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) + 4;
                    poss_map(i,j) = cost_plus4(i,j);
                end
                if(change_possibility_m4(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) - 4;
                    poss_map(i,j) = cost_minus4(i,j);
                end
                if(change_possibility_p5(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) + 5;
                    poss_map(i,j) = cost_plus5(i,j);
                end
                if(change_possibility_m5(i,j))
                    jpeg_dct_new(i,j) = jpeg_dct_stego2(i,j) - 5;
                    poss_map(i,j) = cost_minus5(i,j);
                end
                diff_temp = jpeg_dct_stego2(i,j) - jpeg_dct_new(i,j);
                if(diff_temp==0)
                    poss_map(i,j) = cost_self_old(i,j);
                end
            end
        end
        need_robust = jpeg_dct_new;
end
    if(1)
        protocol_img = protocol_img_backup;
        for i=1:length(all_changed_index_array)
            block_temp = need_robust(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
            protocol_img(1 : 8, ((all_changed_index_array(i) - 1) * 8 + 1) : (all_changed_index_array(i)) * 8) = block_temp;
            old_index = randpermed_protocl(all_changed_index_array(i));
            if(for_show==1)
                block_temp2 = block_temp;
                img_content = uint8(idct2(block_temp2 .* quant_table)+128);
                imwrite(img_content, ['D:\Code\Experiments\forshow\',num2str(old_index),'protocol_robust_embedding.bmp']); 
            end
        end
        stego_robust_protoco_img = protocol_img;
        %%
        %??????DCT?????????
        index = 1;
        for i = 1 : block_num_protocol
            block_dct = protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
            %???????
            block_rho_p1 = protocol_img_rho_p1(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
            block_rho_m1 = protocol_img_rho_m1(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
            nznum = 0;
            for ii = 1 : 8
                for jj = 1 : 8
                    if (ii + jj) > 6 && (ii + jj) < 10
                        if abs(block_dct(ii, jj)) > 1
                            nznum = nznum + 1;
                        end
                    end
                end
            end
            all_index_array_old(i) = nznum; %????1DCT??
            if(nznum >= n && index <662)
                if(index == 661)
                    last_find_index = i;
                end
                nznum_array(index) = nznum;
                block_num(index) = i; %the real block used for embedding
                new_protocol_img(1:8, (index - 1) * 8 + 1 : index * 8) = block_dct;
                new_block_rho_p1(1:8, (index - 1) * 8 + 1 : index * 8) = block_rho_p1;
                new_block_rho_m1(1:8, (index - 1) * 8 + 1 : index * 8) = block_rho_m1;   
                index = index + 1;
            end
        end
        cover_protocol_img = protocol_img;
        [msg_length,msgEmbed,jpeg_dct_stego] =  embedMsgUsingMdlFreRS2Half(new_protocol_img,sequence,3,123456,new_block_rho_p1,new_block_rho_m1,robust_p1,robust_m1,6,661);
        for i=1:661
            new_block = jpeg_dct_stego(1:8, (i-1)*8+1:i*8);
            temp_num = block_num(i);
            protocol_img(1 : 8, ((temp_num - 1) * 8 + 1) : (temp_num) * 8) = new_block;
            %stego image used to embed protocol
        end
        stego_protoco_img = protocol_img;
        %%

        for i = 1 : block_num_protocol
            block_dct = protocol_img(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
            nznum = 0;
            for ii = 1 : 8
                for jj = 1 : 8
                    if (ii + jj) > 6 && (ii + jj) < 10
                        if abs(block_dct(ii, jj)) > 1
                            nznum = nznum + 1;
                        end
                    end
                end
            end
            all_index_array_stego(i) = nznum;
        end
        stego_protocol = protocol_img;
        %%generate stego image
        
        rng(123456);
        randpermed_protocl = randperm(block_num_protocol);
        permed_protocol_img_cover = zeros([8, block_num_protocol]);
        for i = 1 : block_num_protocol
            permed_protocol_img_cover(1:8, (randpermed_protocl(i)-1)*8+1:randpermed_protocl(i)*8) = cover_protocol_img(1 : 8, (i - 1) * 8 + 1 : (i * 8));
        end
        protocol_img_restored_cover = permed_protocol_img_cover;
        index = 1;
        index_inside = 1;
        jpeg_dct_real_cover = before_embedding_dct;
        for i = 1 : 8 : 512
            for j = 1 : 8 : 512
                if nnz((index == embed_for_protocol))>0
                    temp = protocol_img_restored_cover(1 : 8, ((index_inside - 1) * 8 + 1) : (index_inside) * 8);
                    index_inside = index_inside + 1;
                    jpeg_dct_real_cover(i : i + 7, j : j + 7) = temp;
                end
                index = index + 1;
            end
        end
        jpeg_struct.coef_arrays{1} = jpeg_dct_real_cover;
        
        
        
        jpeg_write(jpeg_struct, coverName);
        
        
        for alli=1:4
            %%
            %%?????protocol_img
            payloads = [0.05, 0.1, 0.2, 0.3];
            payload_temp = payloads(alli);
            perm_msg_index = perm_array{alli};
            jpeg_dct = jpeg_pre_embedding{alli};
            embed_numbers = jpeg_embed_number{alli};
            embed_rand_path = embed_rand_path_array{alli};
            msg = msg_array{alli};
            strimm = strim_array{alli};
            rng(123456);
            randpermed_protocl = randperm(block_num_protocol);
            permed_protocol_img = zeros([8, block_num_protocol]);
            for i = 1 : block_num_protocol
                permed_protocol_img(1:8, (randpermed_protocl(i)-1)*8+1:randpermed_protocl(i)*8) = stego_protoco_img(1 : 8, (i - 1) * 8 + 1 : (i * 8));
            end
            protocol_img_restored = permed_protocol_img;
            %%
            index = 1;
            index_inside = 1;
            jpeg_dct_real_stego = jpeg_dct;
            for i = 1 : 8 : 512
                for j = 1 : 8 : 512
                    if nnz((index == embed_for_protocol))>0
                        temp = protocol_img_restored(1 : 8, ((index_inside - 1) * 8 + 1) : (index_inside) * 8);
                        index_inside = index_inside + 1;
                        jpeg_dct_real_stego(i : i + 7, j : j + 7) = temp;
                    end
                    index = index + 1;
                end
            end
            jpeg_struct.coef_arrays{1} = jpeg_dct_real_stego;
            stego_diff = jpeg_dct_old - jpeg_dct_real_stego;
            distortion_all(times) = 0;
            for i=1:512
                for j=1:512
                    if(stego_diff(i,j)~=0)
                        diff_value = stego_diff(i,j);
                        abs_value = abs(diff_value);
                        if(diff_value<0)
                            distortion_all(times) = distortion_all(times) + abs_value * rhoM1J(i, j);
                        else
                            distortion_all(times) = distortion_all(times) + abs_value * rhoP1J(i, j);
                        end
                    end
                end
            end
            if(distortion_all(times)==0)
                test = 1;
            end
            fprintf(fid, 'the distortion is   %f \n',distortion_all(times));
            stegoNameNew = [stegoName,'_', num2str(payload_temp), '.jpg'];
            jpeg_write(jpeg_struct, stegoNameNew);


            %%

            %?????????????
            %??????

            %re_compress_moz(stegoNameNew, qf, [seed,'compressed_2.jpg']);
            img = imread(stegoNameNew);
            imwrite(img, [seed,'compressed_2.jpg'], 'quality', qf);
            jpeg_struct_re = jpeg_read([seed,'compressed_2.jpg']);
            rng(123456);
            rand_num_re = randperm(4096);
            embed_for_msg_re = rand_num_re(1 : 4096/2);
            msg_img_re = zeros([8, 2048 * 8]);
            protocol_img_re = zeros([8, 2048 * 8]);
            index_re = 1;
            jpeg_dct_re = jpeg_struct_re.coef_arrays{1};
            msg_img_index_re = 1;
            protocol_img_index_re = 1;
            %????????1
            for i = 1 : 8 : 512
                for j = 1 : 8 : 512
                    dct_block = jpeg_dct_re(i : i + 7, j : j + 7);
                    if nnz((index_re == embed_for_msg_re))>0
                        msg_img_re(1 : 8, ((msg_img_index_re - 1) * 8 + 1) : (msg_img_index_re) * 8) = dct_block; %?????????
                        msg_img_index_re = msg_img_index_re + 1;
                    else
                        protocol_img_re(1 : 8, ((protocol_img_index_re - 1) * 8 + 1) : (protocol_img_index_re) * 8) = dct_block; %?????????
                        protocol_img_index_re = protocol_img_index_re + 1;
                    end  
                    index_re = index_re + 1;
                end
            end
            %%
            block_num_protocol_re = protocol_img_index_re - 1;
            rng(123456);
            randpermed_protocl = randperm(block_num_protocol_re);
            permed_protocol_img = zeros([8, block_num_protocol_re]);
            for i = 1 : block_num_protocol_re
                permed_protocol_img(1:8, (i-1)*8+1:i*8) = protocol_img_re(1 : 8, (randpermed_protocl(i) - 1) * 8 + 1 : (randpermed_protocl(i) * 8));
            end
            protocol_img_re = permed_protocol_img;
            %%
            %%
            compressed_protocol_img = protocol_img_re;

            for i = 1 : block_num_protocol_re
                block_dct = protocol_img_re(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
                nznum = 0;
                for ii = 1 : 8
                    for jj = 1 : 8
                        if (ii + jj) > 6 && (ii + jj) < 10
                            if abs(block_dct(ii, jj)) > 1
                                nznum = nznum + 1;
                            end
                        end
                    end
                end
                all_index_array_stego_recompress(i) = nznum;
            end
            stego_compress_protocol = protocol_img_re;
            %????????2
            hist_result2 = zeros([1, 100]);
            for i = 1 : block_num_protocol_re
                block_dct = protocol_img_re(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
                nznum = 0;
                for ii = 1 : 8
                    for jj = 1 : 8
                        if (ii + jj) > 6 && (ii + jj) < 10
                            if abs(block_dct(ii, jj)) > 1
                                nznum = nznum + 1;
                            end
                        end
                    end
                end
                if(nznum > 0)
                    hist_result2(uint8(nznum)) =  hist_result2(uint8(nznum)) + 1; %?0??????
                end
            end
            all_num = 0;
            n = 0;
            for i = 100 : -1 : 1
                all_num = hist_result2(i) + all_num;
                if all_num > 661
                    break;
                end
                n = i;
            end
            n = old_n;
            looper = 1;
            while looper
                looper = 0;
                block_num2 = zeros([1, 661]);
                new_protocol_img = zeros([8, 661 * 8]);
                index = 1;
                for i = 1 : block_num_protocol_re
                    block_dct = protocol_img_re(1 : 8, ((i - 1) * 8 + 1) : (i) * 8);
                    nznum = 0;
                    for ii = 1 : 8
                        for jj = 1 : 8
                            if (ii + jj) > 6 && (ii + jj) < 10
                                if abs(block_dct(ii, jj)) > 1
                                    nznum = nznum + 1;
                                end
                            end
                        end
                    end
                    all_index2(i) = nznum;
                    if(nznum >= n && index < 662)
                        nznum_array_re(index) = nznum;
                        block_num2(index) = i; %recovered blocks
                        new_protocol_img(1:8, (index - 1) * 8 + 1 : index * 8) = block_dct;
                        index = index + 1;   
                    end
                end
                protocol_img_stego_re = new_protocol_img;
                diff_stego = protocol_img_stego_re - jpeg_dct_stego;
                [msg_out,msg_extract] = extractMsgUsingMdlFreRS2Half(new_protocol_img,123456,3,msg_length,length(sequence), 661);
                ratio(times) = nnz(msgEmbed - double(msg_extract'))/length(msg_extract(:));
                fprintf(fid, 'the error ratio is   %f \n',ratio(times));
                len = length(msg_out);
                crc_receive = binvec2dec(msg_out(len-31:len));
                store_msg = msg_out(1:len-32);
                crc_recalc = crc32_adler(0, store_msg);
                quit_f = 0;
                sequence_receiver = store_msg;
                zero_index = 1;
                if crc_receive ~= crc_recalc
                    fprintf(fid, 'crc32 different , will continue \n');
                    looper = 0;
                else
                    fprintf(fid, 'crc32 equal , success \n');
                    looper = 0;
                    old_len2 = length(sequence_receiver);
                    msg_bits1 = sequence_receiver(old_len2 - 32 + 1 : old_len2 - 16);
                    msg_bits_len1 = uint32(binvec2dec(msg_bits1));
                    msg_bits2 = sequence_receiver(old_len2 - 16 + 1 : old_len2);
                    msg_bits_len2 = uint32(binvec2dec(msg_bits2));
                    msg_len_arr = [msg_bits_len1, msg_bits_len2];
                    for inside_i = 1: block_num_protocol_re               
                        if sequence_receiver(inside_i) == 0
                            robust_block_re(1 : 8, (zero_index-1)*8+1 : zero_index * 8) = msg_img_re(1:8, (inside_i-1)*8+1:inside_i*8);
                            zero_index = zero_index + 1;
                        end
                    end
                    Y2 = int32(robust_block_re(embed_rand_path));
                    MSG2 = stc_ml_extract(Y2, embed_numbers, 7);
                    if(length(MSG2') == length(msg))
                        diff_msg = double(MSG2') - double(msg);
                        diff_ratio = nnz(diff_msg)/length(diff_msg);
                        fprintf(fid, 'the error ratio of payload %f message is   %f \n', payload_temp, diff_ratio);
                        length_msg = length(MSG2(:));
                        data = zeros([1,length_msg]);
                        for i=1:length_msg
                            data(perm_msg_index(i)) = MSG2(i);
                        end
                        dec=comm.BCHDecoder(bch_n,bch_k);
                        DecMess_All=step(dec,data').';
                        diff_msg = uint8(DecMess_All) - strimm;
                        diff_ratio2 = nnz(diff_msg)/length(diff_msg);
                        fprintf(fid, 'the error ratio in payload %f real message after decoding is  %f \n', payload_temp, diff_ratio2);
                
                    else
                        diff_ratio = -1;
                        fprintf(fid, 'the error ratio of payload %f message is   %f \n', payload_temp, diff_ratio);
                        diff_ratio2 = -1;
                        fprintf(fid, 'the error ratio in payload %f real message after decoding is  %f \n', payload_temp, diff_ratio2);
                        
                    end
                end

            end
        end
    end
    
    
end


%??????????????



%??????DCT???????




%??????????????



%?????????



%???????



