#1.????
#2.????
#3??????
import os
import scipy.io as scio
#import tensorflow as tf
import tensorflow.compat.v1 as tf
tf.compat.v1.disable_eager_execution()
import numpy as np
class RobustnessClassifier(object):
    def __init__(self, net, net_stor_path):
        self.net = net
        self.net_store_path = net_stor_path

    def predict(self, fileName,dstFileName):
        #save_path = os.path.join(self.net_store_path, "model.ckpt")
        gpu_options = tf.GPUOptions(allow_growth=True)
        init = tf.global_variables_initializer()
        with tf.Session(config=tf.ConfigProto(gpu_options=gpu_options)) as sess:
            sess.run(init)
            
            self.net.restore(sess, self.net_store_path)
            for_predict = scio.loadmat(fileName)['spatial']
            all_result = np.zeros([int(for_predict.shape[0]), int(for_predict.shape[1]), int(for_predict.shape[2]), for_predict.shape[3]])
            for layers in range(for_predict.shape[3]):
                layer = for_predict[:,:,:,layers]
                for subLayer in range(int(for_predict.shape[2])):
                    subValue = layer[:,:,subLayer]
                    imgLen = (subValue.shape[0] * subValue.shape[1])/64
                    test_y = np.zeros([int(imgLen),8,8,1])
                    index = 0
                    for ii in range(int(subValue.shape[0]/8)):
                        for jj in range(int(subValue.shape[1]/8)):
                            test_y[index,:,:,0] = subValue[ii*8:ii*8+8,jj*8:jj*8+8]
                            index = index  + 1
                    batch_y = np.zeros([int(imgLen),])
                    soft_max_result = sess.run(self.net.soft_max_result,feed_dict={self.net.x: test_y,
                                                                       self.net.y: batch_y,
                                                                       self.net.keep_prob: 1.})
                    result = np.zeros([int(for_predict.shape[0]),int(for_predict.shape[1])])
                    index = 0
                    for ii in range(int(for_predict.shape[0]/8)):
                        for jj in range(int(for_predict.shape[1] / 8)):
                            result[ii*8:ii*8+8,jj*8:jj*8+8] = soft_max_result[index,1]
                            index = index + 1
                    try:
                        all_result[:,:,subLayer,layers] = result
                    except Exception:
                        print(Exception)
            scio.savemat(dstFileName, {'predict': all_result})



