function [change_possibility_p1,change_possibility_m1,change_possibility_p2, change_possibility_m2,change_possibility_p3,change_possibility_m3,change_possibility_p4,change_possibility_m4, ...
    change_possibility_p5,change_possibility_m5,distortion,cost_plus1,cost_minus1,cost_self_old,cost_plus2,cost_minus2,cost_plus3,cost_minus3,cost_plus4,cost_minus4,cost_plus5,cost_minus5]...
    = flip_possibility_test_distortion_old(jpeg_dct, quant_table,rand_permed_block,seed,qf,rhoP1,rhoM1,old_need_robust,maxphase,max_change,distortion_times)
maxD = 1;
distortion = 0;
x=distortion_times;
max_phase = maxphase;
max_value2 = 0;                                                                                                                                  
[robustP1Real,robustM1Real,cost_plus1,cost_minus1,cost_self,cost_plus2,cost_minus2,cost_plus3,cost_minus3,cost_plus4,cost_minus4,cost_plus5,cost_minus5]...
    = test_robust_embedding(jpeg_dct, quant_table, maxD, rand_permed_block,max_phase,seed,qf);
cost_self_old = cost_self;
cost_self(cost_self<0.5) = 0;
cost_plus2(cost_self<0.5) = 0;
cost_minus2(cost_self<0.5) = 0;
cost_plus1(cost_self<0.5) = 0;
cost_minus1(cost_self<0.5) = 0;
cost_plus3(cost_self<0.5) = 0;
cost_minus3(cost_self<0.5) = 0;
cost_plus4(cost_self<0.5) = 0;
cost_minus4(cost_self<0.5) = 0;
cost_plus5(cost_self<0.5) = 0;
cost_minus5(cost_self<0.5) = 0;
%{
[cost_plus1_2,cost_minus1_2,cost_self_2,cost_plus2_2,cost_minus2_2] = robust_cost_include_self_upgrade(img_name,a);
cost_minus2 = cost_minus2 + cost_minus2_2;
cost_plus2 = cost_plus2 + cost_plus2_2;
cost_self = cost_self + cost_self_2;
cost_plus1 = cost_plus1 + cost_plus1_2;
cost_minus1 = cost_minus1 + cost_minus1_2;
%}
%[cost_plus2,cost_minus2,cost_self2] = robust_cost_include_self(img_name,a);
sizes = size(cost_plus1);
change_possibility_p1 = zeros(sizes);
change_possibility_m1 = zeros(sizes);
change_possibility_p2 = zeros(sizes);
change_possibility_m2 = zeros(sizes);
change_possibility_p3 = zeros(sizes);
change_possibility_m3 = zeros(sizes);
change_possibility_p4 = zeros(sizes);
change_possibility_m4 = zeros(sizes);
change_possibility_p5 = zeros(sizes);
change_possibility_m5 = zeros(sizes);

for i=1:8:sizes(1)
    for j=1:8:sizes(2)
        block_cost_p1 = change_possibility_p1(i:i+7,j:j+7);
        block_cost_m1 = change_possibility_m1(i:i+7,j:j+7);
        block_cost_p2 = change_possibility_p2(i:i+7,j:j+7);
        block_cost_m2 = change_possibility_m2(i:i+7,j:j+7);
        block_cost_p3 = change_possibility_p3(i:i+7,j:j+7);
        block_cost_m3 = change_possibility_m3(i:i+7,j:j+7);
        block_cost_p4 = change_possibility_p4(i:i+7,j:j+7);
        block_cost_m4 = change_possibility_m4(i:i+7,j:j+7);
        block_cost_p5 = change_possibility_p5(i:i+7,j:j+7);
        block_cost_m5 = change_possibility_m5(i:i+7,j:j+7);
        block_old = jpeg_dct(i:i+7,j:j+7);
        block_old_old = old_need_robust(i:i+7,j:j+7);
        block_p1 = block_old + 1;
        block_jcost_p1 = rhoP1(i:i+7,j:j+7)*1;
        block_m1 = block_old - 1;
        block_jcost_m1 = rhoM1(i:i+7,j:j+7)*1;
        block_p2 = block_old + 2;
        block_jcost_p2 = rhoP1(i:i+7,j:j+7)*2;
        block_m2 = block_old - 2;
        block_jcost_m2 = rhoM1(i:i+7,j:j+7)*2;
        block_p3 = block_old + 3;
        block_jcost_p3 = rhoP1(i:i+7,j:j+7)*3;
        block_m3 = block_old - 3;
        block_jcost_m3 = rhoM1(i:i+7,j:j+7)*3;
        block_jcost_p4 = rhoP1(i:i+7,j:j+7)*4;
        block_m3 = block_old - 3;
        block_jcost_m4 = rhoM1(i:i+7,j:j+7)*4;
        block_jcost_p5 = rhoP1(i:i+7,j:j+7)*5;
        block_m3 = block_old - 3;
        block_jcost_m5 = rhoM1(i:i+7,j:j+7)*5;
            
            block_cost_minus1 = cost_minus1(i:i+7,j:j+7);
            block_cost_plus1 = cost_plus1(i:i+7,j:j+7);
            block_cost_minus2 = cost_minus2(i:i+7,j:j+7);
            block_cost_plus2 = cost_plus2(i:i+7,j:j+7);
            block_cost_self = cost_self(i:i+7,j:j+7);
            block_cost_minus3 = cost_minus3(i:i+7,j:j+7);
            block_cost_plus3 = cost_plus3(i:i+7,j:j+7);
            block_cost_minus4 = cost_minus4(i:i+7,j:j+7);
            block_cost_plus4 = cost_plus4(i:i+7,j:j+7);
            block_cost_minus5 = cost_minus5(i:i+7,j:j+7);
            block_cost_plus5 = cost_plus5(i:i+7,j:j+7);
            diff_p1 = block_cost_self - block_cost_plus1; %found the max decline
            diff_m1 = block_cost_self - block_cost_minus1;
            diff_p2 = block_cost_self - block_cost_plus2;
            diff_m2 = block_cost_self - block_cost_minus2;
            diff_p3 = block_cost_self - block_cost_plus3;
            diff_m3 = block_cost_self - block_cost_minus3;
            diff_p4 = block_cost_self - block_cost_plus4;
            diff_m4 = block_cost_self - block_cost_minus4;
            diff_p5 = block_cost_self - block_cost_plus5;
            diff_m5 = block_cost_self - block_cost_minus5;
            diff_p1(diff_p1<0) = 0;
            diff_m1(diff_m1<0) = 0;
            diff_p2(diff_p2<0) = 0;
            diff_m2(diff_m2<0) = 0;
            diff_p3(diff_p3<0) = 0;
            diff_m3(diff_m3<0) = 0;
            diff_p4(diff_p4<0) = 0;
            diff_m4(diff_m4<0) = 0;
            diff_p5(diff_p5<0) = 0;
            diff_m5(diff_m5<0) = 0;
            for ii=1:8
                for jj=1:8
                    if (ii + jj > max_phase)
                        diff_p1(ii,jj) = 0;
                        diff_m1(ii,jj) = 0;
                        diff_p2(ii,jj) = 0;
                        diff_m2(ii,jj) = 0;
                        diff_p3(ii,jj) = 0;
                        diff_m3(ii,jj) = 0;
                        diff_p4(ii,jj) = 0;
                        diff_m4(ii,jj) = 0;
                        diff_p5(ii,jj) = 0;
                        diff_m5(ii,jj) = 0;
                    end
                end
            end    
            for ii=1:max_change
                diff_p1 = diff_p1./(block_jcost_p1.^x);
                diff_m1 = diff_m1./(block_jcost_m1.^x);
                diff_p2 = diff_p2./(block_jcost_p2.^x);
                diff_m2 = diff_m2./(block_jcost_m2.^x);
                diff_p3 = diff_p3./(block_jcost_p3.^x);
                diff_m3 = diff_m3./(block_jcost_m3.^x);
                diff_p4 = diff_p4./(block_jcost_p4.^x);
                diff_m4 = diff_m4./(block_jcost_m4.^x);
                diff_p5 = diff_p5./(block_jcost_p5.^x);
                diff_m5 = diff_m5./(block_jcost_m5.^x);
                
                p1_max = max(diff_p1(:));
                [max_p1_row,max_p1_cell]=find(diff_p1==p1_max);
                if(length(max_p1_row)>0)
                    max_p1_row = max_p1_row(1);
                    max_p1_cell = max_p1_cell(1);
                end
                m1_max = max(diff_m1(:));
                [max_m1_row,max_m1_cell]=find(diff_m1==m1_max);
                if(length(max_m1_row)>0)
                    max_m1_row = max_m1_row(1);
                    max_m1_cell = max_m1_cell(1);
                end
                p2_max = max(diff_p2(:));
                [max_p2_row,max_p2_cell]=find(diff_p2==p2_max);
                if(length(max_p2_row)>0)
                    max_p2_row = max_p2_row(1);
                    max_p2_cell = max_p2_cell(1);
                end
                m2_max = max(diff_m2(:));
                [max_m2_row,max_m2_cell]=find(diff_m2==m2_max);
                if(length(max_m2_row)>0)
                    max_m2_row = max_m2_row(1);
                    max_m2_cell = max_m2_cell(1);
                end
                p3_max = max(diff_p3(:));
                [max_p3_row,max_p3_cell]=find(diff_p3==p3_max);
                if(length(max_p3_row)>0)
                    max_p3_row = max_p3_row(1);
                    max_p3_cell = max_p3_cell(1);
                end
                m3_max = max(diff_m3(:));
                [max_m3_row,max_m3_cell]=find(diff_m3==m3_max);
                if(length(max_m3_row)>0)
                    max_m3_row = max_m3_row(1);
                    max_m3_cell = max_m3_cell(1);
                end
                p4_max = max(diff_p4(:));
                [max_p4_row,max_p4_cell]=find(diff_p4==p4_max);
                if(length(max_p4_row)>0)
                    max_p4_row = max_p4_row(1);
                    max_p4_cell = max_p4_cell(1);
                end
                m4_max = max(diff_m4(:));
                [max_m4_row,max_m4_cell]=find(diff_m4==m4_max);
                if(length(max_m4_row)>0)
                    max_m4_row = max_m4_row(1);
                    max_m4_cell = max_m4_cell(1);
                end
                p5_max = max(diff_p5(:));
                [max_p5_row,max_p5_cell]=find(diff_p5==p5_max);
                if(length(max_p5_row)>0)
                    max_p5_row = max_p5_row(1);
                    max_p5_cell = max_p5_cell(1);
                end
                m5_max = max(diff_m5(:));
                [max_m5_row,max_m5_cell]=find(diff_m5==m5_max);
                if(length(max_m5_row)>0)
                    max_m5_row = max_m5_row(1);
                    max_m5_cell = max_m5_cell(1);
                end
                result_array = [p1_max,m1_max,p2_max,m2_max,p3_max,m3_max];
                max_value = max(result_array(:));
                if max_value>max_value2
                    index = find(result_array==max_value);
                    if(length(index)>1)
                        index = index(1);
                    end
                    if index == 1
                        block_cost_p1(max_p1_row,max_p1_cell) = 1;
                        diff_p1(max_p1_row,max_p1_cell) = 0;
                        distortion = distortion + block_jcost_p1(max_p1_row,max_p1_cell);
                    elseif index==2
                        block_cost_m1(max_m1_row,max_m1_cell) = 1;
                        diff_m1(max_m1_row,max_m1_cell) = 0;
                        distortion = distortion + block_jcost_m1(max_m1_row,max_m1_cell);
                    elseif index==3
                        block_cost_p2(max_p2_row,max_p2_cell) = 1;
                        diff_p2(max_p2_row,max_p2_cell) = 0;
                        distortion = distortion + block_jcost_p2(max_p2_row,max_p2_cell);
                    elseif index==4
                        block_cost_m2(max_m2_row,max_m2_cell) = 1;
                        diff_m2(max_m2_row,max_m2_cell) = 0;
                        distortion = distortion + block_jcost_m2(max_m2_row,max_m2_cell);
                    elseif index==5
                        block_cost_p3(max_p3_row,max_p3_cell) = 1;
                        diff_p3(max_p3_row,max_p3_cell) = 0;
                        distortion = distortion + block_jcost_p3(max_p3_row,max_p3_cell);
                    elseif index==6
                        block_cost_m3(max_m3_row,max_m3_cell) = 1;
                        diff_m3(max_m3_row,max_m3_cell) = 0;
                        distortion = distortion + block_jcost_m3(max_m3_row,max_m3_cell);
                    elseif index==7
                        block_cost_p4(max_p4_row,max_p4_cell) = 1;
                        diff_p4(max_p4_row,max_p4_cell) = 0;
                        distortion = distortion + block_jcost_p4(max_p4_row,max_p4_cell);
                    elseif index==8
                        block_cost_m4(max_m4_row,max_m4_cell) = 1;
                        diff_m4(max_m4_row,max_m4_cell) = 0;
                        distortion = distortion + block_jcost_m4(max_m4_row,max_m4_cell);
                    elseif index==9
                        block_cost_p5(max_p5_row,max_p5_cell) = 1;
                        diff_p5(max_p5_row,max_p5_cell) = 0;
                        distortion = distortion + block_jcost_p5(max_p5_row,max_p5_cell);
                    elseif index==10
                        block_cost_m5(max_m5_row,max_m5_cell) = 1;
                        diff_m5(max_m5_row,max_m5_cell) = 0;
                        distortion = distortion + block_jcost_m5(max_m5_row,max_m5_cell);
                    end

                end

            end
       
        change_possibility_p1(i:i+7,j:j+7) = block_cost_p1;
        change_possibility_m1(i:i+7,j:j+7) = block_cost_m1;
        change_possibility_p2(i:i+7,j:j+7) = block_cost_p2;
        change_possibility_m2(i:i+7,j:j+7) = block_cost_m2;
        change_possibility_p3(i:i+7,j:j+7) = block_cost_p3;
        change_possibility_m3(i:i+7,j:j+7) = block_cost_m3;
        change_possibility_p4(i:i+7,j:j+7) = block_cost_p4;
        change_possibility_m4(i:i+7,j:j+7) = block_cost_m4;
        change_possibility_p5(i:i+7,j:j+7) = block_cost_p5;
        change_possibility_m5(i:i+7,j:j+7) = block_cost_m5;
    end
end

end
        