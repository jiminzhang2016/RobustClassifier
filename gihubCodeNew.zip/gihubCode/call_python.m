function call_python(intput,dst,qf)
    %cmd_str1 = 'cd C:\Users\Xiepei\Documents\Github\Project5\Project\';
  
    cmd_str2 = ['python launcher.py ',intput,' ',dst,' ',num2str(qf)];
    %result_str = [cmd_str1,' && ', cmd_str2];
    [status, cmdout] = system(cmd_str2)
    %cmdout
end