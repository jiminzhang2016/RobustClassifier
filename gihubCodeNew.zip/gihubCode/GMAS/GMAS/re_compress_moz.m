function [dct_value_2,fileOutpue] = re_compress_moz(jpeg_input,quality,fileName)
    fileOutpue = fileName;
    %cmd_str = 'E:';
    %system(cmd_str);
    %cmd_str = 'cd E:\Experiment\mozjpeg-master\';
    %system(cmd_str);
    cmd_str = ['C:\mozjpeg-gcc64\bin\cjpeg.exe -q ',num2str(quality),' -quant-table 0 ',jpeg_input,' >',fileName];
    
    system(cmd_str);
    img_jpeg = jpeg_read(fileName);
    dct_value_2 = img_jpeg.coef_arrays{1};
end