function Test_Robustness_GMAS_JUNIWARD75(payload, stego_dir, recodeFile)
    addpath('.\JPEG_Toolbox','.\STC3');
%% Robustness test code of the robust steganography algorithm GMAS on the actual channel of the social network platform Facebook
    if(exist(stego_dir)==0)
        mkdir(stego_dir);
    end
    resultFile = fopen(recodeFile,'a');
%%  parameter setting
    cover_dir = 'D:\Code\Experiments\Ex75\cover\'; 
     if ~exist(stego_dir,'dir'); mkdir(stego_dir); end  
    afterchannel_stego_dir = 'D:\Code\Experiments\GMAS\channel\'; if ~exist(afterchannel_stego_dir,'dir'); mkdir(afterchannel_stego_dir); end     
    cover_num = 10000; 
    cover_QF = 75; 
    Facebook_attack_QF = 75; 

    
    bit_error_rate = zeros(1,cover_num); 
%%  message embedding   
    for i_img = 1:cover_num
        cover_Path = fullfile([cover_dir,'\',num2str(i_img),'.jpg']);
        if(exist(cover_Path,'file'))
            stego_Path = fullfile([stego_dir,'\',num2str(i_img),'.jpg']);    
            afterchannel_stego_Path = fullfile([afterchannel_stego_dir,'\',num2str(i_img),'.jpg']);   

            C_STRUCT = jpeg_read(cover_Path);
            C_COEFFS = C_STRUCT.coef_arrays{1};  
            C_QUANT = C_STRUCT.quant_tables{1};
            nzAC = nnz(C_COEFFS) - nnz(C_COEFFS(1:8:end,1:8:end));
    %  generating random message and padding
            nn = 31; kk = 15; mm = 5;   %using RS（31,15）for message correction，the length of the message needs to be times of kk*mm=75      
            raw_msg_len = ceil(payload*nzAC);
            raw_msg_len_old = raw_msg_len;
            need_real_raw_msg_len = ceil(raw_msg_len / nn * kk);
            raw_msg = round( rand(1,need_real_raw_msg_len) ); %original message 
            raw_msg_len = need_real_raw_msg_len;
            zeros_padding_num = ceil(raw_msg_len/kk/mm)*kk*mm - raw_msg_len; %the number of padding zero 
            zeros_padding_msg = zeros(1, raw_msg_len + zeros_padding_num); %padding
            zeros_padding_msg(1:raw_msg_len) = raw_msg;
            zeros_padding_msg(raw_msg_len+1 : raw_msg_len + zeros_padding_num) = 0;  %message to be embedded subsequently
    %  The secret information is encoded using RS(31,15)    
            [rs_encoded_msg] = rs_encode_yxz(zeros_padding_msg,nn,kk); 
    %  An improved asymmetric distortion is used to calculate the +-1 asymmetric distortion of the cover 
            [rho1_P, rho1_M] = J_UNIWARD_Asy_cost(cover_Path);         
    %  Message embedded preprocessing (modifying distortion and modifying distance based on generalized dither modulation)
            [cover_round, change_p, change_m, rho_p, rho_m] = gmas(cover_Path, rho1_P, rho1_M, C_QUANT);       
    %  STC embeding     
            [suc, stc_n_msg_bits] = stc3_embed(rs_encoded_msg, cover_Path, cover_round, rho_p, rho_m, change_p, change_m, cover_QF, stego_Path);
    %%  mimic Facebook compression  Facebook_attack_QF = 71   
            %imwrite(imread(stego_Path),afterchannel_stego_Path,'quality',Facebook_attack_QF);    
            if(suc~=1)
                fprintf(resultFile, '%s\n',['encoded msg error_rate: ',num2str(-1)]);  
                continue;
            end
            re_compress_moz(stego_Path,Facebook_attack_QF,afterchannel_stego_Path);
    %  STC extraction
            img_before = jpeg_read(stego_Path);
            img_after = jpeg_read(afterchannel_stego_Path);
            img_before_dct = img_before.coef_arrays{1};
            img_after_dct = img_after.coef_arrays{1};
            diff = img_before_dct - img_after_dct;
            [stc_decoded_msg] = stc3_extract(afterchannel_stego_Path, stc_n_msg_bits, C_QUANT);   
    %  decode message by RS（31,15）
            [rs_decoded_msg] = rs_decode_yxz(double(stc_decoded_msg), nn, kk);
    %  delete padding       
            extract_raw_msg = rs_decoded_msg(1:raw_msg_len); %delete padded zero
    %%  calculate bit error rate        
            fprintf(resultFile, '%s\n', cover_Path);
            bit_error = double(rs_encoded_msg) - double(stc_decoded_msg);
            bit_error_number = sum(abs(bit_error));
            bit_error_rate(1,i_img) = bit_error_number/length(stc_decoded_msg);              
            fprintf(resultFile, '%s\n',['encoded msg error_rate: ',num2str(bit_error_rate(1,i_img))]);  
            
            bit_error2 = double(extract_raw_msg) - double(raw_msg);
            bit_error_number = sum(abs(bit_error2));
            bit_error_rate(1,i_img) = bit_error_number/length(raw_msg);              
            fprintf(resultFile, '%s\n',['msg error_rate: ',num2str(bit_error_rate(1,i_img))]);  
        end
    end
%  give it error rate of all images
    ave_error_rate = mean(bit_error_rate);
    fprintf(resultFile, '%s\n',['payload: ',num2str(payload),'  ave_error_rate: ',num2str(ave_error_rate)]);  
  
end
