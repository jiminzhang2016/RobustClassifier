function batch_GMAS711()
Test_Robustness_GMAS_JUNIWARD75(0.05, 'D:\Code\Experiments\Ex75\GMAS\0.05\', 'D:\Code\Experiments\Ex75\GMAS\result05.txt');
Test_Robustness_GMAS_JUNIWARD75(0.10, 'D:\Code\Experiments\Ex75\GMAS\0.10\', 'D:\Code\Experiments\Ex75\GMAS\result10.txt');
Test_Robustness_GMAS_JUNIWARD75(0.20, 'D:\Code\Experiments\Ex75\GMAS\0.20\', 'D:\Code\Experiments\Ex75\GMAS\result20.txt');
Test_Robustness_GMAS_JUNIWARD75(0.30, 'D:\Code\Experiments\Ex75\GMAS\0.30\', 'D:\Code\Experiments\Ex75\GMAS\result30.txt');
end