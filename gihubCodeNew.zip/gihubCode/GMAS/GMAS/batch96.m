function batch96()
Test_Robustness_GMAS_JUNIWARD(0.05, 'D:\Code\Experiments\A2\method3Ex\GMAS\0.05\', 'D:\Code\Experiments\A2\method3Ex\GMAS\\result05.txt');
Test_Robustness_GMAS_JUNIWARD(0.10, 'D:\Code\Experiments\A2\method3Ex\GMAS\0.10\', 'D:\Code\Experiments\A2\method3Ex\GMAS\\result10.txt');
Test_Robustness_GMAS_JUNIWARD(0.20, 'D:\Code\Experiments\A2\method3Ex\GMAS\0.20\', 'D:\Code\Experiments\A2\method3Ex\GMAS\\result20.txt');
Test_Robustness_GMAS_JUNIWARD(0.30, 'D:\Code\Experiments\A2\method3Ex\GMAS\0.30\', 'D:\Code\Experiments\A2\method3Ex\GMAS\\result30.txt');
end