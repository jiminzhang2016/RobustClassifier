function showBar3(diff1)
sizes = size(diff1);
dct_mode11 = zeros(8,8);
diff_number = 0;
all_number = 0;
for insi = 1:sizes(1)
 for insj = 1:sizes(2)
     modx = mod(insi-1,8)+1;
     mody = mod(insj-1,8)+1;
         if(diff1(insi,insj)~=0)
             dct_mode11(modx,mody) = dct_mode11(modx,mody)+1;
         end
         if( (modx+mody)>6 && (modx+mody)<10)
             all_number = all_number + 1;
             if(diff1(insi,insj)~=0)
                 diff_number = diff_number + 1;
             end
         end
 end
end
dct_mode11(1,1) = 0;
bar3(dct_mode11);

ratio = diff_number / all_number
end
