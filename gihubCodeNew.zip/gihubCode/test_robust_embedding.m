function [robustP1Real,robustM1Real,cost_plus1,cost_minus1,cost_self,cost_plus2,cost_minus2,cost_plus3,cost_minus3,cost_plus4,cost_minus4,cost_plus5,cost_minus5] = test_robust_embedding(jpeg_dct, quant_table, maxD, rand_permed_block,max_phase,seed,qf)
jpeg_coef = jpeg_dct;
jpeg_size = size(jpeg_coef);
cost_plus1 = zeros(jpeg_size);
cost_minus1 = zeros(jpeg_size);
cost_self = zeros(jpeg_size);
cost_plus2 = zeros(jpeg_size);
cost_minus2 = zeros(jpeg_size);
cost_plus3 = zeros(jpeg_size);
cost_minus3 = zeros(jpeg_size);
cost_plus4 = zeros(jpeg_size);
cost_minus4 = zeros(jpeg_size);
cost_plus5 = zeros(jpeg_size);
cost_minus5 = zeros(jpeg_size);
fun = @(x)x.data .* quant_table;
I_spatial = blockproc(jpeg_dct, [8 8], fun);
fun=@(x)idct2(x.data);
I_spatial = blockproc(I_spatial,[8 8],fun)+128; %????
C_QUANT = quant_table;
spatialImpact = cell(8, 8);
%minV = 0+a;
%maxV = 255-a;
cost_block = zeros(8,8);
for bcoord_i=1:8
    for bcoord_j=1:8
        testCoeffs = zeros(8, 8);
        testCoeffs(bcoord_i, bcoord_j) = 1;
        spatialImpact{bcoord_i, bcoord_j} = idct2(testCoeffs)*C_QUANT(bcoord_i, bcoord_j);
        %spatialImpact{bcoord_i, bcoord_j} = idct2(testCoeffs);
    end
end
index = 1;
max_phase = 6;
[size_h, size_w] = size(jpeg_dct);
number = 0;
for ii = 1:8
    for jj=1:8
        if (ii + jj <= max_phase)
            number = number + 1;
        end
    end
end
spatial = zeros([size_h, size_w, 11,number]);
for i=1:8
    for j=1:8
      if(i+j<=max_phase)
          index_inside = 1;
          spatialImp = spatialImpact{i, j};
          for ii=1:rand_permed_block
        
                  spatial_old = I_spatial(1:8, (ii-1)*8 + 1 : ii * 8);
                  
                  spatial_temp = spatialImp + spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,1,index) = spatial_temp;
     

                  spatial_temp = -spatialImp + spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,2,index) = spatial_temp;
               

                  spatial_temp = spatial_old; 
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,3,index) = spatial_temp;
                  

                  spatial_temp = 2 * spatialImp +  spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,4,index) = spatial_temp;
                

                  spatial_temp = -2 * spatialImp +  spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,5,index) = spatial_temp;
            

                  spatial_temp = 3 * spatialImp + spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,6,index) = spatial_temp;
         

                  spatial_temp = -3 * spatialImp + spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,7,index) = spatial_temp;
               

                  spatial_temp = 4 * spatialImp + spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,8,index) = spatial_temp;
                

                  spatial_temp = -4 * spatialImp + spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,9,index) = spatial_temp;
                

                  spatial_temp = 5 * spatialImp + spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,10,index) = spatial_temp;
             

                  spatial_temp = -5 * spatialImp + spatial_old;
                  spatial(1:8,(index_inside-1)*8+1:index_inside*8,11,index) = spatial_temp;
                  

                  index_inside = index_inside + 1;
          end
          index = index + 1;
      end
    end
end
save([seed,'temp_spatial.mat'],'spatial','-v6');
delete([seed,'output.mat']);
call_python([seed,'temp_spatial.mat'],[seed,'output.mat'],qf);%W*H*D*P
load1 = load([seed,'output.mat']);%W*H*D*P(1-64)
all_predict = load1.predict;
index = 1;
for i=1:8
    for j=1:8
      if(i+j<=max_phase)
          index_inside = 1;
          for ii=1:rand_permed_block
                  x_pos = 1;
                  y_pos = (ii-1)*8+1;
                  cost_plus1(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,1,index);
                  cost_minus1(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,2,index);
                  cost_self(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,3,index);
                  cost_plus2(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,4,index);
                  cost_minus2(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,5,index);
                  cost_plus3(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,6,index);
                  cost_minus3(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,7,index);
                  cost_plus4(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,8,index);
                  cost_minus4(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,9,index);
                  cost_plus5(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,10,index);
                  cost_minus5(x_pos+i-1,y_pos+j-1) = all_predict(1,(index_inside-1)*8+1,11,index);
                  index_inside = index_inside + 1;
          end
          index = index + 1;
      end
    end
end
%maxP = max(max(cost_plus1(:)),max(cost_minus1(:)));
%minP = min(min(cost_plus1(:)),min(cost_minus1(:)));
%robustP12 = (cost_plus1-minP)./(maxP - minP+10^-6);
%robustM12 = (cost_minus1-minP)./(maxP - minP+10^-6);
cost_plus1_copy = cost_plus1;
cost_minus1_copy  = cost_minus1;
cost_plus1_copy(cost_plus1_copy<0.5) = 0.5;
cost_minus1_copy(cost_minus1_copy<0.5) = 0.5;
maxP = max(max(cost_plus1_copy(:)),max(cost_minus1_copy(:)));
minP = min(min(cost_plus1_copy(:)),min(cost_minus1_copy(:)));
minP = 0.5;
robustP1Real = (cost_plus1_copy-minP)./(maxP - minP+10^-6);
robustM1Real = (cost_minus1_copy-minP)./(maxP - minP+10^-6);
end
        